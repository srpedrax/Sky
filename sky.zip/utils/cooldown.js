const { JsonDatabase } = require('wio.db');

class CooldownManager {
    static db = new JsonDatabase({ databasePath: './databases/cooldowns.json' });

    static setCooldown(commandName, userId, cooldownTime) {
        const key = `${commandName}_${userId}`;
        const cooldownEnd = Date.now() + cooldownTime;
        this.db.set(key, cooldownEnd);
        setTimeout(() => {
            this.db.delete(key);
        }, cooldownTime);
    }

    static checkCooldown(commandName, userId) {
        const key = `${commandName}_${userId}`;
        const cooldownEnd = this.db.get(key);
        return cooldownEnd ? cooldownEnd - Date.now() : 0;
    }
}

module.exports = CooldownManager;