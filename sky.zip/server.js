app.get('/api/server/:id/channels', async (req, res) => {
  const serverId = req.params.id;

  try {
    const response = await axios.get(`https://discord.com/api/v10/guilds/${serverId}/channels`, {
      headers: {
        Authorization: `Bot ${token}`
      }
    });
    res.json(response.data);
  } catch (error) {
    console.error('Erro ao obter canais do servidor:', error);
    res.status(500).json({ error: 'Erro ao obter canais do servidor' });
  }
});

app.post('/api/server/:id/enable-channel', (req, res) => {
  const serverId = req.params.id;
  const { channelId } = req.body;

  if (!channelId) {
    return res.status(400).json({ error: 'channelId é obrigatório' });
  }

  const serverData = db.get(serverId) || { disabledChannels: [] };
  const index = serverData.disabledChannels.findIndex(channel => channel.channelId === channelId);

  if (index > -1) {
    serverData.disabledChannels.splice(index, 1);
    db.set(serverId, serverData);
    res.json({ message: 'Canal ativado com sucesso' });
  } else {
    res.status(400).json({ error: 'Canal não está desativado' });
  }
});

app.post('/api/server/:id/disable-channel', (req, res) => {
  const serverId = req.params.id;
  const { channelId, channelName } = req.body;

  if (!channelId || !channelName) {
    return res.status(400).json({ error: 'channelId e channelName são obrigatórios' });
  }

  const serverData = db.get(serverId) || { disabledChannels: [] };
  const channelExists = serverData.disabledChannels.some(channel => channel.channelId === channelId);

  if (!channelExists) {
    serverData.disabledChannels.push({ channelId, channelName });
    db.set(serverId, serverData);
    res.json({ message: 'Canal desativado com sucesso' });
  } else {
    res.status(400).json({ error: 'Canal já está desativado' });
  }
});

app.get('/api/server/:id/disabled-channels', (req, res) => {
  const serverId = req.params.id;
  const serverData = db.get(serverId);

  if (serverData && serverData.disabledChannels) {
    res.json(serverData.disabledChannels);
  } else {
    res.status(404).json({ error: 'Servidor não encontrado ou nenhum canal desativado' });
  }
});