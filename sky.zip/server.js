const express = require('express');
const session = require('express-session');
const passport = require('passport');
const DiscordStrategy = require('passport-discord').Strategy;
const cors = require('cors');
const { JsonDatabase } = require('wio.db');
const CooldownManager = require('./utils/cooldown');

const app = express();

// Configurar CORS
app.use(cors({
  origin: ['https://sky-bot-website.web.app', 'https://sky-bot-website.firebaseapp.com'],
  credentials: true
}));

// Configurar sessão
app.use(session({
  secret: '_FvawPa_45gsMHXuzUUqwLelrYK2hFVY',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: false, // Defina como true em produção com HTTPS
    httpOnly: true
  }
}));

app.use(passport.initialize());
app.use(passport.session());

passport.serializeUser((user, done) => {
  done(null, user);
});

passport.deserializeUser((obj, done) => {
  done(null, obj);
});

// Configurar estratégia OAuth2
passport.use(new DiscordStrategy({
  clientID: '1087702470806999041',
  clientSecret: '_FvawPa_45gsMHXuzUUqwLelrYK2hFVY',
  callbackURL: 'http://localhost:3000/callback',
  scope: ['identify', 'email']
}, (accessToken, refreshToken, profile, done) => {
  process.nextTick(() => {
    return done(null, profile);
  });
}));

// Rotas
app.get('/login', passport.authenticate('discord'));

const dbG = new JsonDatabase({ databasePath: './databases/myJsonGeral.json' });

app.get('/callback', passport.authenticate('discord', { failureRedirect: '/' }), (req, res) => {
  const userData = dbG.get(req.user.id) || {};

  userData.username = req.user.username;
  userData.avatar = req.user.avatar;
  userData.email = req.user.email;
  userData.skyCoin = userData.skyCoin || 0; // Certifique-se de inicializar skyCoin

  dbG.set(req.user.id, userData);

  res.redirect(`https://sky-bot-website.web.app/index.html?username=${req.user.username}&id=${req.user.id}&avatar=${req.user.avatar}&email=${req.user.email}`);
});

app.get('/logout', (req, res) => {
  req.logout();
  res.redirect('/');
});

app.get('/api/user', (req, res) => {
  if (req.isAuthenticated()) {
    res.json(req.user);
  } else {
    res.status(401).send('Não autenticado');
  }
});

app.get('/api/user/:id', (req, res) => {
  const userId = req.params.id;
  const userData = dbG.get(userId);

  if (userData) {
    res.json(userData);
  } else {
    res.status(404).send('Usuário não encontrado');
  }
});

function generateDailyReward() {
  const random = Math.random();
  if (random <= 0.01) {
    return Math.floor(Math.random() * (1000000 - 5000 + 1)) + 5000;
  } else {
    return Math.floor(Math.random() * (10000 - 1000 + 1)) + 1000;
  }
}

const cooldownTime = 24 * 60 * 60 * 1000;

app.post('/api/user/:id/daily', (req, res) => {
  const userId = req.params.id;
  const userData = dbG.get(userId);

  if (userData) {
    const cooldown = CooldownManager.checkCooldown("daily", userId);
    
    if (cooldown > 0) {
      return res.status(429).json({ cooldown: cooldown });
    }

    const reward = generateDailyReward();
    userData.skyCoin += reward;
    dbG.set(userId, userData);
    CooldownManager.setCooldown("daily", userId, cooldownTime);
    
    res.json({ ...userData, reward });
  } else {
    res.status(404).send('Usuário não encontrado');
  }
});

app.get('/api/user/:id/daily', (req, res) => {
  const userId = req.params.id;
  const userData = dbG.get(userId);
  
  if (userData) {
    const cooldown = CooldownManager.checkCooldown("daily", userId);
    res.json({ cooldown: cooldown });
  } else {
    res.status(404).send('Usuário não encontrado');
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor ouvindo na porta ${PORT}`);
});