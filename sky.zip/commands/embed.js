const { MessageActionRow, MessageButton, MessageEmbed, Modal, TextInputComponent } = require('discord.js');

module.exports = {
  name: 'createembed',
  aliases: ['embedcreate', 'embed', 'makeembed'],
  description: 'Cria e envia uma embed personalizada com um painel de botões para configuração.',

  async execute(message, args) {
    if (!message.member.permissions.has('ADMINISTRATOR')) {
      return message.reply('Você não tem permissão para usar este comando.');
    }

    const embed = new MessageEmbed()
      .setColor('#0099ff')
      .setDescription('Descrição temporária'); // Adicione uma descrição temporária para evitar o erro

    const row1 = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setCustomId('setTitle')
          .setLabel('Definir Título')
          .setStyle('PRIMARY'),
        new MessageButton()
          .setCustomId('setDescription')
          .setLabel('Definir Descrição')
          .setStyle('PRIMARY'),
        new MessageButton()
          .setCustomId('addField')
          .setLabel('Adicionar Campo')
          .setStyle('PRIMARY'),
        new MessageButton()
          .setCustomId('setColor')
          .setLabel('Definir Cor')
          .setStyle('PRIMARY')
      );

    const row2 = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setCustomId('setThumbnail')
          .setLabel('Definir Thumbnail')
          .setStyle('PRIMARY'),
        new MessageButton()
          .setCustomId('setImage')
          .setLabel('Definir Imagem')
          .setStyle('PRIMARY'),
        new MessageButton()
          .setCustomId('setTimestamp')
          .setLabel('Adicionar Timestamp')
          .setStyle('PRIMARY'),
        new MessageButton()
          .setCustomId('sendEmbed')
          .setLabel('Enviar Embed')
          .setStyle('SUCCESS')
      );

    const embedMessage = await message.channel.send({ content: 'Use os botões abaixo para configurar a embed.', embeds: [embed], components: [row1, row2] });

    const buttonFilter = i => i.user.id === message.author.id;
    const collector = embedMessage.createMessageComponentCollector({ filter: buttonFilter, time: 600000 });

    collector.on('collect', async i => {
      if (i.customId === 'setTitle' || i.customId === 'setDescription' || i.customId === 'setColor' || i.customId === 'setThumbnail' || i.customId === 'setImage') {
        const modal = new Modal()
          .setCustomId(i.customId)
          .setTitle('Configuração da Embed');

        const input = new TextInputComponent()
          .setCustomId('input')
          .setLabel('Digite o valor:')
          .setRequired(true)
          .setStyle('SHORT');

        if (i.customId === 'setTitle') {
          modal.setTitle('Definir Título');
          input.setLabel('Título da Embed');
        } else if (i.customId === 'setDescription') {
          modal.setTitle('Definir Descrição');
          input.setLabel('Descrição da Embed');
        } else if (i.customId === 'setColor') {
          modal.setTitle('Definir Cor');
          input.setLabel('Cor em hexadecimal (ex: #0099ff)');
        } else if (i.customId === 'setThumbnail') {
          modal.setTitle('Definir Thumbnail');
          input.setLabel('URL da Thumbnail');
        } else if (i.customId === 'setImage') {
          modal.setTitle('Definir Imagem');
          input.setLabel('URL da Imagem');
        }

        modal.addComponents(new MessageActionRow().addComponents(input));
        await i.showModal(modal);
      } else if (i.customId === 'addField') {
        const fieldModal = new Modal()
          .setCustomId('addField')
          .setTitle('Adicionar Campo');

        const fieldNameInput = new TextInputComponent()
          .setCustomId('fieldName')
          .setLabel('Nome do Campo')
          .setRequired(true)
          .setStyle('SHORT');
          
        const fieldValueInput = new TextInputComponent()
          .setCustomId('fieldValue')
          .setLabel('Valor do Campo')
          .setRequired(true)
          .setStyle('SHORT');

        fieldModal.addComponents(
          new MessageActionRow().addComponents(fieldNameInput),
          new MessageActionRow().addComponents(fieldValueInput)
        );

        await i.showModal(fieldModal);
      } else if (i.customId === 'setTimestamp') {
        embed.setTimestamp();
        await embedMessage.edit({ embeds: [embed] });
        await i.reply({ content: 'Timestamp adicionado à embed.', ephemeral: true });
      } else if (i.customId === 'sendEmbed') {
        const channelModal = new Modal()
          .setCustomId('channelModal')
          .setTitle('Enviar Embed');

        const channelIdInput = new TextInputComponent()
          .setCustomId('channelId')
          .setLabel('ID do Canal')
          .setRequired(true)
          .setStyle('SHORT');

        channelModal.addComponents(new MessageActionRow().addComponents(channelIdInput));
        await i.showModal(channelModal);
      }
    });

    message.client.on('interactionCreate', async interaction => {
      if (!interaction.isModalSubmit()) return;

      const modalId = interaction.customId;

      try {
        if (modalId === 'setTitle') {
          const title = interaction.fields.getTextInputValue('input');
          embed.setTitle(title);
          await interaction.update({ embeds: [embed] });
        } else if (modalId === 'setDescription') {
          const description = interaction.fields.getTextInputValue('input');
          embed.setDescription(description);
          await interaction.update({ embeds: [embed] });
        } else if (modalId === 'setColor') {
          const color = interaction.fields.getTextInputValue('input');
          embed.setColor(color);
          await interaction.update({ embeds: [embed] });
        } else if (modalId === 'setThumbnail') {
          const thumbnail = interaction.fields.getTextInputValue('input');
          embed.setThumbnail(thumbnail);
          await interaction.update({ embeds: [embed] });
        } else if (modalId === 'setImage') {
          const image = interaction.fields.getTextInputValue('input');
          embed.setImage(image);
          await interaction.update({ embeds: [embed] });
        } else if (modalId === 'addField') {
          const fieldName = interaction.fields.getTextInputValue('fieldName');
          const fieldValue = interaction.fields.getTextInputValue('fieldValue');
          embed.addField(fieldName, fieldValue, true);
          await interaction.update({ embeds: [embed] });
        } else if (modalId === 'channelModal') {
          const channelId = interaction.fields.getTextInputValue('channelId');
          const channel = message.guild.channels.cache.get(channelId);

          if (!channel || channel.type !== 'GUILD_TEXT') {
            throw new Error('Canal inválido ou não é um canal de texto.');
          }

          await channel.send({ embeds: [embed] });
          collector.stop();
          await interaction.reply({ content: 'Embed enviada com sucesso!', ephemeral: true });
          embedMessage.delete(); // Deleta a mensagem de configuração para não poluir o canal
        }
      } catch (error) {
        const errorEmbed = new MessageEmbed()
          .setTitle('Erro')
          .setDescription(`Ocorreu um erro: ${error.message}`)
          .setColor('RED');

        await interaction.followUp({ embeds: [errorEmbed], ephemeral: true });
      }
    });

    collector.on('end', () => {
      embedMessage.edit({ content: 'Configuração da embed concluída.', components: [] });
    });
  },
};