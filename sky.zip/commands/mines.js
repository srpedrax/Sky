const Discord = require('discord.js');
const { JsonDatabase } = require('wio.db');

const db = new JsonDatabase({ databasePath: './databases/myJsonGeral.json' });

module.exports = {
  name: 'mines',
  aliases: ['campo-minado'],
  description: 'Jogue um jogo simples de campo minado!',
  usage: '<aposta> <bombas>',
  async execute(message, args) {
    const aposta = parseInt(args[0]);
    const bombas = parseInt(args[1]);
    const db1 = db.get(message.author.id) || {};

    if (!args.length || args.length < 2) {
      return message.reply('Você precisa fornecer uma aposta e o número de bombas. Ex: `mines <aposta> <bombas>`');
    }

    if (isNaN(aposta) || aposta <= 0) {
      return message.reply('A aposta deve ser um número válido maior que zero.');
    }

    if ((db1.skyCoin || 0) < aposta) {
      return message.reply('Você não tem Sky Coins suficientes para essa aposta.');
    }

    if (aposta < 10) {
      return message.reply('A aposta mínima é de 10 Sky Coins.');
    }

    if (aposta > 10000) {
      return message.reply('A aposta máxima é de 10,000 Sky Coins.');
    }

    // Verificar se o número de bombas é válido
    if (isNaN(bombas) || bombas < 1 || bombas > 10) {
      return message.reply('O número de bombas deve estar entre 1 e 10.');
    }

    let winnings = aposta;

    // Calcular o multiplicador com base no número de bombas
    const multiplier = 1 + (bombas / 10);

    const width = 5;
    const height = 5;
    let board = Array(height).fill().map(() => Array(width).fill('⬛'));
    let bombPositions = [];
    let position = { x: Math.floor(width / 2), y: Math.floor(height / 2) };
    let diamondsFound = 0;
    board[position.y][position.x] = '🟦';

    // Array para rastrear células reveladas
    let revealedCells = Array(height).fill().map(() => Array(width).fill(false));

    // Gerar posições das bombas
    for (let i = 0; i < bombas; i++) {
      let x = Math.floor(Math.random() * width);
      let y = Math.floor(Math.random() * height);
      if (board[y][x] === '⬛') {
        bombPositions.push({ x, y });
      } else {
        i--; // Bomba colocada em um local já ocupado, tentar novamente
      }
    }

    const row1 = new Discord.MessageActionRow()
      .addComponents(
        new Discord.MessageButton()
          .setCustomId('up')
          .setEmoji('⬆️')
          .setStyle('SECONDARY'),
        new Discord.MessageButton()
          .setCustomId('left')
          .setEmoji('⬅️')
          .setStyle('SECONDARY'),
        new Discord.MessageButton()
          .setCustomId('down')
          .setEmoji('⬇️')
          .setStyle('SECONDARY'),
        new Discord.MessageButton()
          .setCustomId('right')
          .setEmoji('➡️')
          .setStyle('SECONDARY')
      );

    const row2 = new Discord.MessageActionRow()
      .addComponents(
        new Discord.MessageButton()
          .setCustomId('reveal')
          .setLabel('Revelar')
          .setStyle('PRIMARY'),
        new Discord.MessageButton()
          .setCustomId('collect')
          .setLabel('Coletar')
          .setStyle('SUCCESS')
      );

    const currentTimestampInSeconds = Math.floor(Date.now() / 1000);
    const fiveMinutesInMilliseconds = 5 * 60 * 1000;
    const newTimestampInSeconds = Math.floor((Date.now() + fiveMinutesInMilliseconds) / 1000);

    const embed = new Discord.MessageEmbed()
      .setTitle('Campo Minado')
      .setDescription(`${board.map(row => row.join(' ')).join('\n')}\n\nO tempo acaba <t:${newTimestampInSeconds}:R>`)
      .setColor('GREEN');

    const sentMessage = await message.channel.send({ content: `Você encontrou ${diamondsFound} Diamantes, tem ${aposta} Sky Coins acumulados e ${db1.skyCoin} Sky Coins!`, embeds: [embed], components: [row1, row2] });

    const filter = i => i.user.id === message.author.id;
    const collector = sentMessage.createMessageComponentCollector({ filter, time: 300000 });

    collector.on('collect', async i => {
      const previousPosition = { ...position };

      if (i.customId === 'up' && position.y > 0) {
        position.y--;
      } else if (i.customId === 'down' && position.y < height - 1) {
        position.y++;
      } else if (i.customId === 'left' && position.x > 0) {
        position.x--;
      } else if (i.customId === 'right' && position.x < width - 1) {
        position.x++;
      }

      if (position.x !== previousPosition.x || position.y !== previousPosition.y) {
        if (board[previousPosition.y][previousPosition.x] !== '💣' && board[previousPosition.y][previousPosition.x] !== '💎') {
          board[previousPosition.y][previousPosition.x] = revealedCells[previousPosition.y][previousPosition.x] ? '💎' : '⬛';
        }
      }

      board[position.y][position.x] = '🟦';

      if (i.customId === 'reveal') {
        if (bombPositions.some(pos => pos.x === position.x && pos.y === position.y)) {
          board[position.y][position.x] = '💣';
          embed.setDescription(`${board.map(row => row.join(' ')).join('\n')}\n\n**💥 BOOM!** Você revelou uma bomba e perdeu ${winnings} Sky Coins.`);
          await i.update({ embeds: [embed], components: [] });
          collector.stop();
          return;
        } else {
          if (!revealedCells[position.y][position.x]) {
            board[position.y][position.x] = '💎';
            revealedCells[position.y][position.x] = true;
            diamondsFound++;
            winnings = aposta * diamondsFound * multiplier;
          }
        }
      } else if (i.customId === 'collect') {
        if (winnings > aposta) {
          db1.skyCoin += winnings;
          db.set(interaction.user.id, db1); // Adicionar ganhos ao saldo do usuário
          await i.update({ content: `💰 Você coletou ${diamondsFound} diamantes e ganhou ${winnings} Sky Coins!`, components: [] });
          embed.setDescription(`${board.map(row => row.join(' ')).join('\n')}\n\nVocê coletou suas recompensas!`);
        } else {
          await i.update({ content: `Você não ganhou nada, pois o valor acumulado é igual ao valor apostado.`, components: [] });
        }
        collector.stop();
        return;
      }

      embed.setDescription(`${board.map(row => row.join(' ')).join('\n')}\n\nO tempo acaba <t:${newTimestampInSeconds}:R>`);
      await i.update({ content: `Você encontrou ${diamondsFound} Diamantes, tem ${winnings} Sky Coins acumulados e ${db1.skyCoin} Sky Coins! `, embeds: [embed] });
    });

    collector.on('end', () => {
      sentMessage.edit({ components: [] });
    });
  },
};