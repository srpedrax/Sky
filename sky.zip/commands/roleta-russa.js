const Discord = require('discord.js');
const { JsonDatabase } = require('wio.db');
const db = new JsonDatabase({ databasePath: './databases/myJsonGeral.json' });

module.exports = {
  name: 'roletarussa',
  aliases: ['russianroulette', 'roleta', 'russa'],
  description: 'Jogue um jogo de roleta russa com Sky Coins!',
  usage: '<aposta>',
  async execute(message, args) {
    let aposta = parseInt(args[0]);
    if (!aposta) {
      return message.reply(':x: ┃ Nenhuma aposta fornecida! Use **`roletarussa <aposta>`**!');
    }
    const db1 = db.get(message.author.id) || {};

    if (aposta < 10) {
      return message.reply('A aposta mínima é de 10 Sky Coins.');
    } else if ((db1.skyCoin ?? 0) < aposta) {
      return message.reply('Desculpe, mas você não tem Sky Coins suficientes para fazer essa aposta.');
    }

    let rodada = 1;
    let ganhos = aposta;

    const multiplicadores = [2, 4, 6, 7, 9, 10];

    const jogarRoleta = async (i, collector) => {
      const random = Math.random();
      let resultEmbed;

      if (random < 1 / (7 - rodada + 1)) { // Probabilidade de perder aumenta a cada rodada
        db1.skyCoin -= aposta;
        resultEmbed = new Discord.MessageEmbed()
          .setTitle('🔫 | Roleta Russa')
          .setDescription(`💥 **Bang!** Que pena <@${message.author.id}>, você perdeu **${ganhos}** Sky Coins`)
          .setColor('RED');
        await i.update({ embeds: [resultEmbed], components: [] });
        db.set(message.author.id, db1);
        collector.stop();
      } else { // Chance de ganhar
        ganhos = ganhos * multiplicadores[rodada - 1];
        rodada++;
        if (rodada > 6) { // O jogador sobreviveu todas as rodadas
          db1.skyCoin += ganhos;
          resultEmbed = new Discord.MessageEmbed()
            .setTitle('🔫 | Roleta Russa')
            .setDescription(`😅 **Click!** Parabéns <@${message.author.id}>, você sobreviveu todas as rodadas e ganhou **${ganhos}** Sky Coins!`)
            .setColor('GREEN');
          await i.update({ embeds: [resultEmbed], components: [] });
          db.set(message.author.id, db1);
          collector.stop();
        } else {
          resultEmbed = new Discord.MessageEmbed()
            .setTitle('🔫 | Roleta Russa')
            .setDescription(`😅 **Click!** Parabéns <@${message.author.id}>, você sobreviveu esta rodada e agora tem **${ganhos}** Sky Coins!\n\nVocê quer tentar novamente? (Rodada ${rodada} de 7 com multiplicador x${multiplicadores[rodada - 1]})`)
            .setColor('GREEN');
          const row = new Discord.MessageActionRow()
            .addComponents(
              new Discord.MessageButton()
                .setCustomId('continuar')
                .setLabel('Continuar')
                .setEmoji('🔫')
                .setStyle('PRIMARY'),
              new Discord.MessageButton()
                .setCustomId('parar')
                .setLabel('Parar')
                .setStyle('SECONDARY')
            );
          await i.update({ embeds: [resultEmbed], components: [row] });
        }
      }
    };

    const row = new Discord.MessageActionRow()
      .addComponents(
        new Discord.MessageButton()
          .setCustomId('puxar_gatilho')
          .setLabel('Puxar o Gatilho')
          .setEmoji('🔫')
          .setStyle('PRIMARY')
      );

    const embed = new Discord.MessageEmbed()
      .setTitle('🔫 | Roleta Russa')
      .setDescription(`Você apostou **${aposta}** Sky Coins\nClique no botão abaixo para puxar o gatilho.`)
      .setColor('#8b0000')
      .setFooter('Boa sorte!');

    const sentMessage = await message.reply({ embeds: [embed], components: [row], fetchReply: true });

    const filter = i => i.user.id === message.author.id;
    const collector = sentMessage.createMessageComponentCollector({ filter, time: 600000 });

    collector.on('collect', async i => {
      if (i.customId === 'puxar_gatilho' || i.customId === 'continuar') {
        await jogarRoleta(i, collector);
      } else if (i.customId === 'parar') {
        db1.skyCoin += ganhos;
        const resultEmbed = new Discord.MessageEmbed()
          .setTitle('🔫 | Roleta Russa')
          .setDescription(`Parabéns <@${i.user.id}>, você decidiu parar e levou para casa **${ganhos}** Sky Coins!`)
          .setColor('GREEN');
        await i.update({ embeds: [resultEmbed], components: [] });
        db.set(i.user.id, db1);
        collector.stop();
      }
    });

    collector.on('end', collected => {
      if (collected.size === 0) {
        sentMessage.edit({ content: 'Tempo esgotado! Você não puxou o gatilho a tempo.', components: [] });
      }
    });
  },
};