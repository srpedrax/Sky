const { JsonDatabase } = require('wio.db');
const Discord = require('discord.js');
const dbG = new JsonDatabase({ databasePath: './databases/myJsonGeral.json' });
const CooldownManager = require('../utils/cooldown');

module.exports = {
  name: 'atm',
  aliases: ['bal', 'saldo'],
  description: 'Verifique quantos Sky Coins você ou outro usuário possui!',
  execute(message, args) {
    const user = message.mentions.members.first() || message.author;
    const userData = dbG.get(user.id) || {};
    
    if (!userData || !userData.skyCoin) {
      return message.reply(`<@${user.id}> não tem Sky Coins`);
    }

    const allUsers = dbG.all();
    const sortedUsers = allUsers.sort((a, b) => b.data.skyCoin - a.data.skyCoin);
    
    const userPosition = sortedUsers.findIndex(userData => userData.ID === user.id) + 1;
    
    if (user.id === message.author.id) {
      if (userData.skyCoin <= 0) {
        message.reply(`Você atualmente não possui nenhum Sky Coin!`);
      } else {
        message.reply(`Você tem **${userData.skyCoin} Sky Coins**! Você está em **#${userPosition} lugar no ranking!**`);
      }
    } else {
      if (userData.skyCoin <= 0) {
        message.reply(`<@${user.id}> atualmente não possui nenhum Sky Coin!`);
      } else {
        message.reply(`<@${user.id}> tem **${userData.skyCoin} Sky Coins**! Ele está em **#${userPosition} lugar no ranking!**`);
      }
    }
  },
};