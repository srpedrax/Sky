const Discord = require('discord.js');
const { JsonDatabase } = require('wio.db');
const db = new JsonDatabase({ databasePath: './databases/myJsonGeral.json' });
const CooldownManager = require('../utils/cooldown');

module.exports = {
  name: "daily",
  aliases: ["d", "mimo", "bonus"],
  description: "Resgate um mimo diário!",
  execute(message, args) {
    const db1 = db.get(message.author.id) || {};
    const cooldownTime = 24 * 60 * 60 * 1000;

    if (CooldownManager.checkCooldown("daily", message.author.id) > 0) {
      const remainingTime = CooldownManager.checkCooldown("daily", message.author.id);
      const horas = Math.floor(remainingTime / (1000 * 60 * 60));
      const minutos = Math.floor((remainingTime % (1000 * 60 * 60)) / (1000 * 60));
      const segundos = Math.floor((remainingTime % (1000 * 60)) / 1000);

      message.reply({
        content: `Aguarde ${horas} horas, ${minutos} minutos e ${segundos} segundos antes de resgatar novamente.`
      });
      return;
    }

    const random = Math.floor(Math.random() * 3000) + 1;

    db1.skyCoin = (db1.skyCoin ?? 0) + random;

    const embed = new Discord.MessageEmbed()
      .setTitle('🗓 | Recompensa Diária')
      .setDescription(`Parabéns <@${message.author.id}> você ganhou <:skycoin:1223026697624879238> **${random}** Sky Coin`)
      .setColor('GREEN');

    message.reply({ embeds: [embed] });

    db.set(message.author.id, db1);

    CooldownManager.setCooldown("daily", message.author.id, cooldownTime);
  },
};