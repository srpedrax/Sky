const axios = require('axios');
const { MessageActionRow, MessageButton, MessageEmbed } = require('discord.js');

let results = [];

module.exports = {
  name: 'usersearch',
  aliases: ['searchuser', 'finduser', 'lookupuser'],
  description: 'Procura usuários de Roblox por palavra-chave.',
  async execute(message, args) {
    const keyword = args.join(' ');
    const limit = 100; // Limite de pesquisa
    let page = 1; // Página inicial
    let totalPages;

    if (!keyword) {
      return message.reply({ content: 'Por favor, forneça uma palavra-chave para pesquisar.', ephemeral: true });
    }

    try {
      await message.channel.sendTyping();

      const embed = await searchAndCreateEmbed(keyword, limit, page);
      const row = createPaginationRow(page);

      const sentMessage = await message.channel.send({ embeds: [embed], components: [row] });

      const filter = i => i.user.id === message.author.id;
      const collector = sentMessage.createMessageComponentCollector({ filter, time: 60000 });

      collector.on('collect', async i => {
        if (i.customId === 'prev' && page > 1) {
          page--;
        } else if (i.customId === 'next' && page < totalPages) {
          page++;
        }

        await i.deferUpdate();

        try {
          const newEmbed = await searchAndCreateEmbed(keyword, limit, page);
          const newRow = createPaginationRow(page);

          await sentMessage.edit({ embeds: [newEmbed], components: [newRow] });
        } catch (error) {
          const errorEmbed = new MessageEmbed()
            .setColor('#FF0000')
            .setTitle('Erro na Pesquisa')
            .setDescription(error.message);
          if (i.deferred) {
            await i.followUp({ embeds: [errorEmbed], ephemeral: true });
          } else {
            await i.reply({ embeds: [errorEmbed], ephemeral: true });
          }
        }
      });

      collector.on('end', async () => {
        const disabledRow = new MessageActionRow()
          .addComponents(
            new MessageButton()
              .setCustomId('prev')
              .setLabel('⬅️')
              .setStyle('PRIMARY')
              .setDisabled(true),
            new MessageButton()
              .setCustomId('next')
              .setLabel('➡️')
              .setStyle('PRIMARY')
              .setDisabled(true)
          );
        await sentMessage.edit({ components: [disabledRow] });
      });
    } catch (error) {
      console.error('Erro ao buscar usuários:', error);
      const errorEmbed = new MessageEmbed()
        .setColor('#FF0000')
        .setTitle('Erro na Pesquisa')
        .setDescription('Ocorreu um erro ao buscar usuários. Tente novamente mais tarde.');
      await message.channel.send({ embeds: [errorEmbed] });
    }
  },
};

async function searchAndCreateEmbed(keyword, limit, page) {
  try {
    const response = await axios.get('https://users.roblox.com/v1/users/search', {
      params: {
        keyword: keyword,
        limit: limit
      }
    });

    results = response.data.data;
  } catch (error) {
    if (error.response) {
      const errorCode = error.response.data.errors[0].code;
      let errorMessage;

      if (errorCode === 5) {
        errorMessage = 'A palavra-chave foi filtrada. Por favor, tente outra.';
      } else if (errorCode === 6) {
        errorMessage = 'A palavra-chave é muito curta. Por favor, forneça uma palavra-chave mais longa.';
      } else if (errorCode === 0) {
        errorMessage = 'Houve muitas solicitações. Por favor, aguarde um pouco e tente novamente.';
      } else {
        errorMessage = 'Houve um erro ao processar a solicitação. Por favor, tente novamente mais tarde.';
      }
      throw new Error(errorMessage);
    } else {
      throw new Error('Houve um erro ao processar a solicitação. Por favor, tente novamente mais tarde.');
    }
  }

  if (!results || results.length === 0) {
    throw new Error('Usuários não encontrados');
  }

  totalPages = Math.ceil(results.length / 10); // Sempre exibir 10 resultados por página

  const embed = new MessageEmbed()
    .setColor('#0099ff')
    .setTitle(`Resultado da pesquisa por "${keyword}"`)
    .setDescription(`Página ${page}/${totalPages}`);

  const start = (page - 1) * 10;
  const end = Math.min(start + 10, results.length);
  for (let i = start; i < end; i++) {
    embed.addField(`Usuário ${i + 1}`, `**Nome de exibição:** ${results[i].displayName}\n**Nome de usuário:** ${results[i].name}\n**ID:** ${results[i].id}`);
  }

  return embed;
}

function createPaginationRow(page) {
  const row = new MessageActionRow()
    .addComponents(
      new MessageButton()
        .setCustomId('prev')
        .setLabel('⬅️')
        .setStyle('PRIMARY')
        .setDisabled(page === 1),
      new MessageButton()
        .setCustomId('next')
        .setLabel('➡️')
        .setStyle('PRIMARY')
        .setDisabled(page === totalPages)
    );

  return row;
}