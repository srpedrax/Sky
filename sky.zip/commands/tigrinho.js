const Discord = require('discord.js');
const { JsonDatabase } = require('wio.db');
const db = new JsonDatabase({ databasePath: './databases/myJsonGeral.json' });

module.exports = {
  name: 'tigrinho',
  aliases: ['tigergame', 'jogotigrinho', 'tiger'],
  description: 'Jogue o jogo do tigrinho!',
  async execute(message, args) {
    let aposta = parseInt(args[0]);
    let db1 = db.get(message.author.id) || { skyCoin: 0 };

    if (isNaN(aposta)) {
      await message.reply('Por favor, forneça uma quantidade válida para apostar.');
      return;
    }

    if (aposta < 10) {
      await message.reply('A aposta mínima é de 10 Sky Coins.');
      return;
    } else if ((db1.skyCoin ?? 0) < aposta) {
      await message.reply('Desculpe, mas você não tem Sky Coins suficientes para fazer essa aposta.');
      return;
    }

    const row = new Discord.MessageActionRow()
      .addComponents(
        new Discord.MessageButton()
          .setCustomId('min')
          .setLabel('Aposta Mínima')
          .setEmoji('🔻')
          .setStyle('SECONDARY'),
        new Discord.MessageButton()
          .setCustomId('decrease')
          .setLabel('Diminuir')
          .setEmoji('➖')
          .setStyle('SECONDARY'),
        new Discord.MessageButton()
          .setCustomId('result')
          .setLabel('Resultado')
          .setEmoji('🎲')
          .setStyle('PRIMARY'),
        new Discord.MessageButton()
          .setCustomId('increase')
          .setLabel('Aumentar')
          .setEmoji('➕')
          .setStyle('SECONDARY'),
        new Discord.MessageButton()
          .setCustomId('max')
          .setLabel('Aposta Máxima')
          .setEmoji('🔺')
          .setStyle('SECONDARY'),
      );

    const embed = new Discord.MessageEmbed()
      .setTitle('🐯 | Jogo do Tigrinho')
      .setDescription(`Sua aposta atual é **${aposta}** Sky Coins\nSeu saldo é **${db1.skyCoin}** Sky Coins`)
      .setColor('ORANGE')
      .setFooter('Use os botões abaixo para ajustar sua aposta');

    const sentMessage = await message.channel.send({ embeds: [embed], components: [row] });

    const filter = i => i.user.id === message.author.id;
    const collector = sentMessage.createMessageComponentCollector({ filter, time: 600000 });

    collector.on('collect', async i => {
      if (i.customId === 'min') {
        aposta = 10;
      } else if (i.customId === 'decrease') {
        if (aposta <= 10) {
          await i.reply({ content: 'A aposta mínima é de 10 Sky Coins.', ephemeral: true });
          return;
        }
        aposta -= 10;
      } else if (i.customId === 'increase') {
        if ((db1.skyCoin ?? 0) < aposta + 10) {
          await i.reply({ content: 'Desculpe, mas você não tem Sky Coins suficientes para aumentar a aposta.', ephemeral: true });
          return;
        }
        aposta += 10;
      } else if (i.customId === 'max') {
        aposta = db1.skyCoin;
      } else if (i.customId === 'result') {
        const random = Math.random();
        let resultEmbed;

        if (random < 0.75) { // 75% de chance de perder
          db1.skyCoin -= aposta;
          resultEmbed = new Discord.MessageEmbed()
            .setTitle('🐯 | Jogo do Tigrinho')
            .setDescription(`😢 Que pena <@${i.user.id}>, você perdeu **${aposta}** Sky Coins`)
            .setColor('RED');
        } else { // 25% de chance de ganhar
          // O usuário ganha o dobro do que apostou
          const ganho = aposta * 2;
          db1.skyCoin += ganho;
          resultEmbed = new Discord.MessageEmbed()
            .setTitle('🐯 | Jogo do Tigrinho')
            .setDescription(`🎉 Parabéns <@${i.user.id}>! Você ganhou **${ganho}** Sky Coins!`)
            .setColor('GREEN');

          // Chance mínima de soltar a cartinha
          const chanceCartinha = Math.random();
          if (chanceCartinha < 0.1) { // 10% de chance
            const multiplicador = Math.floor(Math.random() * (10 - 2 + 1)) + 2; // Multiplicador aleatório entre 2 e 10
            const ganhoExtra = aposta * multiplicador;
            db1.skyCoin += ganhoExtra;
            let bonusName = '';
            if (multiplicador >= 3 && multiplicador <= 5) {
              bonusName = 'Ganho Bônus';
            } else if (multiplicador >= 6 && multiplicador <= 7) {
              bonusName = 'Grande Ganho';
            } else if (multiplicador >= 8 && multiplicador <= 9) {
              bonusName = 'Mega Ganho';
            } else if (multiplicador === 10) {
              bonusName = 'Super Ganho';
            }
            resultEmbed.addField(`${bonusName}!`, `✨ O tigrinho soltou a cartinha e você ganhou **${ganhoExtra}** Sky Coins extra!`);
          }
        }

        await i.update({ embeds: [resultEmbed], components: [] });
        db.set(message.author.id, db1);
        collector.stop();
        return;
      }

      const updatedEmbed = new Discord.MessageEmbed()
        .setTitle('🐯 | Jogo do Tigrinho')
        .setDescription(`Sua aposta atual é **${aposta}** Sky Coins\nSeu saldo é **${db1.skyCoin}** Sky Coins`)
        .setColor('ORANGE')
        .setFooter('Use os botões abaixo para ajustar sua aposta');

      await i.update({ embeds: [updatedEmbed] });
    });

    collector.on('end', () => {
      sentMessage.edit({ components: [] });
    });
  },
};