const Discord = require('discord.js');
const https = require('https');

module.exports = {
  name: 'minecraft',
  aliases: ['mc'],
  description: 'Exibe informações sobre Minecraft.',
  async execute(message, args) {
    if (!args.length) {
      return message.reply('Você precisa fornecer um subcomando: `server` ou `player`.');
    }

    const command = args.shift().toLowerCase();

    if (command === 'server') {
      if (!args.length) {
        return message.reply('Você precisa fornecer um IP do servidor Minecraft.');
      }
      const ip = args.join(' ');
      const serverInfo = await getServerInfo(ip);
      const embed = new Discord.MessageEmbed()
        .setTitle('Informações do servidor')
        .setDescription(serverInfo);
      message.channel.send({ embeds: [embed] });
    } else if (command === 'player') {
      if (!args.length) {
        return message.reply('Você precisa fornecer um nome de usuário do jogador Minecraft.');
      }
      const username = args.join(' ');
      const playerInfo = await getPlayerInfo(username);
      message.channel.send(playerInfo);
    } else {
      message.reply('Comando inválido! Use `server` ou `player`.');
    }
  },
};

let emoji;
let infoServerVersion;

async function getServerInfo(ip) {
  return new Promise((resolve, reject) => {
    https.get(`https://api.mcsrvstat.us/2/${ip}`, (res) => {
      let data = '';
      res.on('data', (chunk) => {
        data += chunk;
      });
      res.on('end', () => {
        const serverInfo = JSON.parse(data);
        if (!serverInfo) {
          resolve('Este servidor não existe!');
        }
        emoji = serverInfo.online ? '🟢' : '🔴';
        infoServerVersion = serverInfo.version ? serverInfo.version : "Versão não especificada";
        if (serverInfo.online) {
          resolve(`**IP:** ${serverInfo.ip}\n**Porta:** ${serverInfo.port}\n**Link:** ${serverInfo.hostname}\n**Online:** ${emoji}\n**Jogadores Online:** ${serverInfo.players.online}\n**Versão:** ${infoServerVersion}`);
          icon = serverInfo.icon;
        } else {
          resolve(`**IP:** ${serverInfo.ip}\n**Link:** ${serverInfo.hostname}\n**Online:** ${emoji}\n**Versão:** ${infoServerVersion}`);
        }
      });
    }).on('error', (err) => {
      console.error('Erro ao obter informações do servidor:', err);
      resolve('Ocorreu um erro ao obter informações do servidor. Tente novamente mais tarde! ');
    });
  });
}

async function getPlayerInfo(username) {
  return new Promise((resolve, reject) => {
    const unixTimestamp = Math.floor(Date.now() / 1000);
    https.get(`https://api.mojang.com/users/profiles/minecraft/${username}?at=${unixTimestamp}`, (res) => {
      let data = '';
      res.on('data', (chunk) => {
        data += chunk;
      });
      res.on('end', () => {
        const playerInfo = JSON.parse(data);
        if (!playerInfo) {
          resolve('O jogador especificado não foi encontrado.');
        } else {
          resolve(`**Nome de Usuário:** ${playerInfo.name}\n**UUID:** ${playerInfo.id}`);
        }
      });
    }).on('error', (err) => {
      console.error('Erro ao obter informações do jogador:', err);
      resolve('Ocorreu um erro ao obter informações do jogador.');
    });
  });
}