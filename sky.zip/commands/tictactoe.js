const { MessageActionRow, MessageButton, MessageEmbed } = require('discord.js');
const gamesByChannel = new Map();

function checkWinner(board) {
  for (let i = 0; i < 3; i++) {
    if (board[i][0] !== ' ' && board[i][0] === board[i][1] && board[i][0] === board[i][2]) {
      return board[i][0];
    }
  }
  for (let j = 0; j < 3; j++) {
    if (board[0][j] !== ' ' && board[0][j] === board[1][j] && board[0][j] === board[2][j]) {
      return board[0][j];
    }
  }
  if (board[0][0] !== ' ' && board[0][0] === board[1][1] && board[0][0] === board[2][2]) {
    return board[0][0];
  }
  if (board[0][2] !== ' ' && board[0][2] === board[1][1] && board[0][2] === board[2][0]) {
    return board[0][2];
  }
  return null;
}

function displayBoard(board) {
  let boardString = '';
  for (let i = 0; i < 3; i++) {
    boardString += `${board[i].join(' | ')}\n`;
    if (i < 2) {
      boardString += '---------\n';
    }
  }
  return boardString;
}

async function handlePlayerMove(game, row, col, interaction) {
  if (interaction.user.id !== game.currentPlayerId) {
    await interaction.reply({ content: `Ainda não é a sua vez, jogador ${game.currentPlayer}.`, ephemeral: true });
    return;
  }
  if (game.board[row][col] === ' ') {
    game.board[row][col] = game.currentPlayer;
    const winner = checkWinner(game.board);
    if (winner) {
      const winnerEmbed = new MessageEmbed()
        .setTitle('Jogo da Velha')
        .setDescription(`O jogador ${winner} venceu!`)
        .addField('Tabuleiro Final', '```\n' + displayBoard(game.board) + '```')
        .setColor('GREEN');
      await interaction.update({ embeds: [winnerEmbed], components: [] });
      gamesByChannel.delete(interaction.channel.id);
      return;
    }
    if (game.board.flat().every(cell => cell !== ' ')) {
      const drawEmbed = new MessageEmbed()
        .setTitle('Jogo da Velha')
        .setDescription('O jogo empatou!')
        .addField('Tabuleiro Final', '```\n' + displayBoard(game.board) + '```')
        .setColor('YELLOW');
      await interaction.update({ embeds: [drawEmbed], components: [] });
      gamesByChannel.delete(interaction.channel.id);
      return;
    }
    game.currentPlayer = game.currentPlayer === 'X' ? 'O' : 'X';
    game.currentPlayerId = game.currentPlayerId === game.challengerId ? game.opponentId : game.challengerId;
    const updatedEmbed = new MessageEmbed()
      .setTitle('Jogo da Velha')
      .setDescription(`É a vez do jogador ${game.currentPlayer}`)
      .addField('Tabuleiro', '```\n' + displayBoard(game.board) + '```')
      .setColor('BLUE');
    await interaction.update({ embeds: [updatedEmbed], components: interaction.message.components });
  } else {
    await interaction.reply({ content: 'Essa célula já está ocupada. Escolha outra.', ephemeral: true });
  }
}

module.exports = {
  name: 'tictactoe',
  aliases: ['jogodavelha', 'velha', 'ttt'],
  description: 'Inicia um jogo de Jogo da Velha.',
  async execute(message, args) {
    const opponent = message.mentions.users.first();
    if (!opponent || opponent.bot || opponent.id === message.author.id) {
      return message.reply('Por favor, mencione um jogador válido (que não seja um bot e que não seja você mesmo).');
    }

    const board = [
      [' ', ' ', ' '],
      [' ', ' ', ' '],
      [' ', ' ', ' ']
    ];
    let currentPlayer = 'X';
    const challenger = message.author;
    const newGame = {
      challengerId: challenger.id,
      opponentId: opponent.id,
      board,
      currentPlayer,
      currentPlayerId: challenger.id
    };

    gamesByChannel.set(message.channel.id, newGame);

    const initialBoard = displayBoard(newGame.board);
    const embed = new MessageEmbed()
      .setTitle('Jogo da Velha')
      .setDescription(`É a vez do jogador ${newGame.currentPlayer}`)
      .addField('Tabuleiro', '```\n' + initialBoard + '```')
      .setColor('BLUE');

    const row1 = new MessageActionRow()
      .addComponents(
        new MessageButton().setCustomId('00').setLabel('ㅤ').setStyle('SECONDARY'),
        new MessageButton().setCustomId('01').setLabel('ㅤ').setStyle('SECONDARY'),
        new MessageButton().setCustomId('02').setLabel('ㅤ').setStyle('SECONDARY')
      );

    const row2 = new MessageActionRow()
      .addComponents(
        new MessageButton().setCustomId('10').setLabel('ㅤ').setStyle('SECONDARY'),
        new MessageButton().setCustomId('11').setLabel('ㅤ').setStyle('SECONDARY'),
        new MessageButton().setCustomId('12').setLabel('ㅤ').setStyle('SECONDARY')
      );

    const row3 = new MessageActionRow()
      .addComponents(
        new MessageButton().setCustomId('20').setLabel('ㅤ').setStyle('SECONDARY'),
        new MessageButton().setCustomId('21').setLabel('ㅤ').setStyle('SECONDARY'),
        new MessageButton().setCustomId('22').setLabel('ㅤ').setStyle('SECONDARY')
      );

    await message.channel.send({ embeds: [embed], components: [row1, row2, row3] });

    const filter = i => i.user.id === newGame.challengerId || i.user.id === newGame.opponentId;
    const collector = message.channel.createMessageComponentCollector({ filter, time: 600000 });

    collector.on('collect', async interaction => {
      const [row, col] = interaction.customId.split('');
      await handlePlayerMove(newGame, row, col, interaction);
    });

    collector.on('end', () => {
      message.channel.send('Tempo esgotado. O jogo foi encerrado.');
    });
  },
};