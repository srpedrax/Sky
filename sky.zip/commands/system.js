const { JsonDatabase } = require('wio.db');
const dbG = new JsonDatabase({ databasePath: './databases/myJsonGeral.json' });

module.exports = {
  name: 'system',
  aliases: ['sys'],
  description: 'Faça alterações em meu sistema.',
  execute(message, args) {
    // Verificar se o usuário é o dono do bot
    if (message.author.id !== '681831921239851069') {
      return message.channel.send('❌️ | Apenas meu dono pode usar esse comando!');
    }

    // Verificar se os argumentos são fornecidos corretamente
    if (args.length < 2) {
      return message.channel.send('Uso correto: !system <ban/unban> <usuário>');
    }

    const action = args[0].toLowerCase();
    const user = message.mentions.users.first() || message.guild.members.cache.get(args[1]);

    if (!user) {
      return message.channel.send('Usuário não encontrado.');
    }

    if (action === 'ban') {
      const db = dbG.get(user.id) || {};
      if (db.isBanned) {
        return message.channel.send(`Usuário <@${user.id}> já está banido!`);
      } else {
        db.isBanned = true;
        dbG.set(user.id, db);
        return message.channel.send(`Usuário <@${user.id}> banido do meu sistema com sucesso, ninguém mandou quebrar as regras!`);
      }
    } else if (action === 'unban') {
      const db = dbG.get(user.id) || {};
      if (!db.isBanned) {
        return message.channel.send(`Usuário <@${user.id}> já está desbanido!`);
      } else {
        db.isBanned = false;
        dbG.set(user.id, db);
        return message.channel.send(`Usuário <@${user.id}> desbanido do meu sistema com sucesso. Bem-vindo novamente!`);
      }
    } else {
      return message.channel.send('Ação inválida. Use "ban" ou "unban".');
    }
  },
};