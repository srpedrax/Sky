const Discord = require("discord.js");

module.exports = {
  name: 'interactionCreate',
  execute: async (interaction) => {
    if (!interaction.isModalSubmit()) return;
    if (interaction.customId === 'myModal') {
      await interaction.reply({ content: 'Your submission was received successfully!' });
    }
  },
};