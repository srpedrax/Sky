const { Client, Intents, Collection } = require('discord.js');
const Discord = require('discord.js');
const { token, clientId } = require('./config.json');
const fs = require('fs');
const path = require('path');
const { JsonDatabase } = require('wio.db');
const db = new JsonDatabase({ databasePath: './databases/myJsonServers.json' });
const dbG = new JsonDatabase({ databasePath: './databases/myJsonGeral.json' });
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');


const intents = new Intents([
  Intents.FLAGS.GUILDS,
  Intents.FLAGS.GUILD_MESSAGES,
  Intents.FLAGS.GUILD_MEMBERS,
]);

const app = express();
app.use(bodyParser.json());
app.use(cors());

const client = new Client({ intents });

client.commands = new Collection();
const slashCommands = new Collection();

const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));
for (const file of commandFiles) {
    const command = require(`./commands/${file}`);
    client.commands.set(command.name, command);
}

const selectMenuEventFiles = fs.readdirSync('./eventsModal').filter(file => file.endsWith('.js'));
for (const file of selectMenuEventFiles) {
  const selectMenuEvent = require(`./eventsModal/${file}`);
  client.on(selectMenuEvent.name, selectMenuEvent.execute);
}

const slashCommandFiles = fs.readdirSync('./slash_commands').filter(file => file.endsWith('.js'));
for (const file of slashCommandFiles) {
    const command = require(`./slash_commands/${file}`);
    slashCommands.set(command.data.name, command);
}
client.once('ready', async () => {
    console.log(`Bot is ready!\nNome: ${client.user.tag}\nAvatar URL: ${client.user.displayAvatarURL()}`);

    // Registro dos slash commands globalmente
    try {
        const rest = await client.application?.fetch();
        await rest?.commands.set(slashCommands.map(command => command.data.toJSON()));
        console.log('Slash Commands registrados globalmente com sucesso!');
    } catch (error) {
        console.error('Error registering slash commands:', error);
    }
});

client.on('interactionCreate', async interaction => {
    if (!interaction.isCommand()) return;

    const { commandName } = interaction;

    if (!commandName) return;

    const dbU = dbG.get(interaction.user.id) || {};
    if (dbU.isBanned) {
        return interaction.reply(`Você está banido do meu sistema!`);
    }

    try {
        if (commandName === 'help') {
            await slashCommands.get(commandName).execute(interaction, client);
        } else {
            await slashCommands.get(commandName).execute(interaction);
        }
    } catch (error) {
        console.error(error);
        await interaction.reply({ content: 'Houve um erro ao executar este comando!', ephemeral: true });
    }
});

client.on('messageCreate', async message => {
  const dbS = db.get(message.guild.id) || {};
  let prefix = dbS.prefix || 'sk.';

  // Verifica se a mensagem começa com o prefixo, ignorando maiúsculas/minúsculas
  if (!message.content.toLowerCase().startsWith(prefix.toLowerCase()) || message.author.bot) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const commandName = args.shift().toLowerCase();

  // Função para encontrar o comando ou alias correspondente
  const findCommand = (name) => {
    if (client.commands.has(name)) {
      return client.commands.get(name);
    }

    for (const command of client.commands.values()) {
      if (command.aliases && command.aliases.includes(name)) {
        return command;
      }
    }

    return null;
  };

  const command = findCommand(commandName);
  if (!command) return;

  // Verificação de banimento
  const dbU = dbG.get(message.author.id) || {};
  if (dbU.isBanned) {
    return message.reply('Você está banido do meu sistema!');
  }

  try {
    await command.execute(message, args);
  } catch (error) {
    console.error(error);
    message.reply('Houve um erro ao executar este comando!');
  }
});

client.on('guildCreate', async guild => {
  const server = {
    id: guild.id
  };
  
  try {
    const auditLogs = await guild.fetchAuditLogs({ limit: 1, type: 'BOT_ADD' });
    const entry = auditLogs.entries.first();

    if (entry) {
      const user = entry.executor;
      const embed = new Discord.MessageEmbed()
        .setTitle('Obrigado por adicionar o bot!')
        .setDescription(`Olá ${user.username}, obrigado por me adicionar ao servidor! Espero que eu seja útil e traga diversão para seus membros!`)
        .setColor('#00ff00');

      user.send({ embeds: [embed] })
        .catch(error => console.error(`Erro ao enviar mensagem para o usuário que adicionou o bot: ${error}`));
    }
  } catch (error) {
    console.error(`Erro ao buscar logs de auditoria: ${error}`);
  }
});

client.on('guildMemberRemove', member => {
  const server = db.get(member.guild.id);
  delete server.membersDatabase[member.user.id];
  db.set(member.guild.id, server);
});


const unixTimestamp = Math.floor(Date.now() / 1000);

client.login(token);