const { Client, Intents, Collection } = require('discord.js');
const Discord = require('discord.js');
const { clientId } = require('./config.json');
const conf = require('./config.json');
const fs = require('fs');
const path = require('path');
const { JsonDatabase } = require('wio.db');
const db = new JsonDatabase({ databasePath: './databases/myJsonServers.json' });
const dbG = new JsonDatabase({ databasePath: './databases/myJsonGeral.json' });
const bodyParser = require('body-parser');

const token = process.argv[3] || conf.token;

const intents = new Intents([
  Intents.FLAGS.GUILDS,
  Intents.FLAGS.GUILD_MESSAGES,
  Intents.FLAGS.GUILD_MEMBERS,
]);

const client = new Client({ intents });

client.commands = new Collection();
const slashCommands = new Collection();

const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));
for (const file of commandFiles) {
    const command = require(`./commands/${file}`);
    client.commands.set(command.name, command);
}

const selectMenuEventFiles = fs.readdirSync('./eventsModal').filter(file => file.endsWith('.js'));
for (const file of selectMenuEventFiles) {
  const selectMenuEvent = require(`./eventsModal/${file}`);
  client.on(selectMenuEvent.name, selectMenuEvent.execute);
}

const slashCommandFiles = fs.readdirSync('./slash_commands').filter(file => file.endsWith('.js'));
for (const file of slashCommandFiles) {
    const command = require(`./slash_commands/${file}`);
    slashCommands.set(command.data.name, command);
}
client.once('ready', async () => {
    console.log(`Bot is ready!\nNome: ${client.user.tag}\nAvatar URL: ${client.user.displayAvatarURL()}`);

    // Registro dos slash commands globalmente
    try {
        const rest = await client.application?.fetch();
        await rest?.commands.set(slashCommands.map(command => command.data.toJSON()));
        console.log('Slash Commands registrados globalmente com sucesso!');
    } catch (error) {
        console.error('Error registering slash commands:', error);
    }
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand()) return;

  const { commandName, channel } = interaction;

  if (!commandName) return;

  const dbU = dbG.get(interaction.user.id) || {};
  if (dbU.isBanned) {
    return interaction.reply(`Você está banido do meu sistema!`);
  }

  const dbS = db.get(interaction.guild.id) || {};
  const disabledChannels = dbS.disabledChannels || [];

  const channelId = channel.id;
  const channelName = channel.name;

  try {
    if (disabledChannels?.some(channel => channel.channelId === channelId)) {
      return interaction.reply({ content: `Este canal (${channelName}) está desativado para o uso de meus comandos.`, ephemeral: true });
    }

    if (commandName === 'ajuda') {
      await slashCommands.get(commandName).execute(interaction, client);
    } else {
      await slashCommands.get(commandName).execute(interaction);
    }
  } catch (error) {
    console.error(error);
    await interaction.reply({ content: 'Houve um erro ao executar este comando!', ephemeral: true });
  }
});

client.on('messageCreate', async message => {
  const dbS = db.get(message.guild.id) || {};
  const prefix = dbS.prefix || 'sk.';

  if (!message.content.toLowerCase().startsWith(prefix.toLowerCase()) || message.author.bot) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const commandName = args.shift().toLowerCase();

  const findCommand = (name) => {
    if (client.commands.has(name)) {
      return client.commands.get(name);
    }

    for (const command of client.commands.values()) {
      if (command.aliases && command.aliases.includes(name)) {
        return command;
      }
    }

    return null;
  };

  const command = findCommand(commandName);
  if (!command) return;

  const dbU = dbG.get(message.author.id) || {};
  if (dbU.isBanned) {
    return message.reply('Você está banido do meu sistema!');
  }

  const disabledChannels = dbS.disabledChannels || [];
  const channelId = message.channel.id;

  if (disabledChannels.some(channel => channel.channelId === channelId)) {
    return message.reply('Este canal está desativado para o uso de comandos.').then(msg => {
      setTimeout(() => {
        msg.delete();
        message.delete();
      }, 2000);
    });
  }

  try {
    await command.execute(message, args);
  } catch (error) {
    console.error(error);
    message.reply('Houve um erro ao executar este comando!');
  }
});

client.on('guildCreate', async guild => {
  const server = {
    id: guild.id
  };
  
  db.set(guild.id, server)
  try {
    const auditLogs = await guild.fetchAuditLogs({ limit: 1, type: 'BOT_ADD' });
    const entry = auditLogs.entries.first();

    if (entry) {
      const user = entry.executor;
      const embed = new Discord.MessageEmbed()
        .setTitle('Obrigado por adicionar o bot!')
        .setDescription(`Olá ${user.username}, obrigado por me adicionar ao servidor! Espero que eu seja útil e traga diversão para seus membros!`)
        .setColor('#00ff00');

      user.send({ embeds: [embed] })
        .catch(error => console.error(`Erro ao enviar mensagem para o usuário que adicionou o bot: ${error}`));
    }
  } catch (error) {
    console.error(`Erro ao buscar logs de auditoria: ${error}`);
  }
});

client.on('guildMemberRemove', member => {
  const server = db.get(member.guild.id);
  if (member.bot) return;
  delete server.membersDatabase[member.user.id];
  db.set(member.guild.id, server);
});


const unixTimestamp = Math.floor(Date.now() / 1000);

const express = require('express');
const session = require('express-session');
const passport = require('passport');
const DiscordStrategy = require('passport-discord').Strategy;
const cors = require('cors');
const axios = require('axios');
const CooldownManager = require('./utils/cooldown');

const app = express();

// Configurar CORS
app.use(cors({
  origin: ['https://sky-bot-website.web.app', 'https://sky-bot-website.firebaseapp.com'],
  credentials: true
}));

// Configurar sessão
app.use(session({
  secret: '_FvawPa_45gsMHXuzUUqwLelrYK2hFVY',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: false,
    httpOnly: true
  }
}));

app.use(passport.initialize());
app.use(passport.session());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

passport.serializeUser((user, done) => {
  done(null, user);
});

passport.deserializeUser((obj, done) => {
  done(null, obj);
});

// Configurar estratégia OAuth2
passport.use(new DiscordStrategy({
  clientID: '1087702470806999041',
  clientSecret: '_FvawPa_45gsMHXuzUUqwLelrYK2hFVY',
  callbackURL: 'http://localhost:3000/callback',
  scope: ['identify', 'email', 'guilds', 'guilds.members.read']
}, (accessToken, refreshToken, profile, done) => {
  process.nextTick(() => {
    profile.accessToken = accessToken;
    return done(null, profile);
  });
}));

// Rotas
app.get('/login', passport.authenticate('discord'));

app.get('/callback', passport.authenticate('discord', { failureRedirect: '/' }), (req, res) => {
  const userData = dbG.get(req.user.id) || {};

  userData.username = req.user.username;
  userData.avatar = req.user.avatar;
  userData.email = req.user.email;
  userData.access_token = req.user.accessToken;
  userData.skyCoin = userData.skyCoin || 0;

  dbG.set(req.user.id, userData);

  res.redirect(`https://sky-bot-website.web.app/index.html?username=${req.user.username}&id=${req.user.id}&avatar=${req.user.avatar}&email=${req.user.email}&access_token=${req.user.accessToken}`); // Corrigindo o nome do parâmetro do token de acesso
});

app.get('/logout', (req, res) => {
  req.logout();
  res.redirect('/');
});

app.get('/api/user', (req, res) => {
  if (req.isAuthenticated()) {
    res.json(req.user);
  } else {
    res.status(401).send('Não autenticado');
  }
});

app.get('/api/user/:id', (req, res) => {
  const userId = req.params.id;
  const userData = dbG.get(userId);

  if (userData) {
    res.json(userData);
  } else {
    res.status(404).send('Usuário não encontrado');
  }
});

function generateDailyReward() {
  const random = Math.random();
  if (random <= 0.01) {
    return Math.floor(Math.random() * (1000000 - 5000 + 1)) + 5000;
  } else {
    return Math.floor(Math.random() * (10000 - 1000 + 1)) + 1000;
  }
}

const cooldownTime = 24 * 60 * 60 * 1000;

app.post('/api/user/:id/daily', (req, res) => {
  const userId = req.params.id;
  const userData = dbG.get(userId);

  if (userData) {
    const cooldown = CooldownManager.checkCooldown("daily", userId);
    
    if (cooldown > 0) {
      return res.status(429).json({ cooldown: cooldown });
    }

    const reward = generateDailyReward();
    userData.skyCoin += reward;
    dbG.set(userId, userData);
    CooldownManager.setCooldown("daily", userId, cooldownTime);
    
    res.json({ ...userData, reward });
  } else {
    res.status(404).send('Usuário não encontrado');
  }
});

app.get('/api/user/:id/daily', (req, res) => {
  const userId = req.params.id;
  const userData = dbG.get(userId);
  
  if (userData) {
    const cooldown = CooldownManager.checkCooldown("daily", userId);
    res.json({ cooldown: cooldown });
  } else {
    res.status(404).send('Usuário não encontrado');
  }
});

function ensureAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
    return next();
  } else {
    res.status(401).send('Não autenticado');
  }
}

app.get('/api/user/:id/servers', async (req, res) => {
  const userId = req.params.id;
  const userData = dbG.get(userId);

  try {
    // Obter a lista de servidores em que o bot está presente
    const botGuilds = client.guilds.cache.map(guild => guild.id);

    const response = await axios.get('https://discord.com/api/v10/users/@me/guilds', {
      headers: {
        Authorization: `Bearer ${userData.access_token}`
      }
    });

    const userGuilds = response.data;

    const userServers = await Promise.all(userGuilds.map(async guild => {
      try {
        const guildMember = await client.guilds.resolve(guild.id).members.fetch(userId);
        const hasAdminPermissions = guild.owner || guildMember.permissions.has('ADMINISTRATOR');
        const botInGuild = botGuilds.includes(guild.id);
        if (hasAdminPermissions && botInGuild) {
          return {
            id: guild.id,
            name: guild.name,
            owner: guild.owner,
            icon: guild.icon,
            permissions: guildMember.permissions.toArray()
          };
        } else {
          return null;
        }
      } catch (error) {
        console.error(`Erro ao processar guilda ${guild.id}:`, error);
        return null;
      }
    }));

    const validUserServers = userServers.filter(guild => guild !== null);
    console.log(`Servidores encontrados para o usuário com ID ${userId}:`, validUserServers);
    res.json(validUserServers);
  } catch (error) {
    console.error(error);
    res.status(500).send('Erro ao obter as guildas do usuário');
  }
});

app.get('/api/server/:id/prefix', async (req, res) => {
  const serverId = req.params.id;
  const serverData = db.get(serverId) || {};

  if (!serverData) {
    return res.status(404).json({ error: 'Servidor não encontrado' });
  }

  res.json({ prefix: serverData.prefix || 'sk.' });
});

app.put('/api/server/:id/prefix', async (req, res) => {
  const serverId = req.params.id;
  const newPrefix = req.body.prefix;

  if (!newPrefix) {
    return res.status(400).json({ error: 'Prefixo não fornecido' });
  }

  let serverData = db.get(serverId);

  if (!serverData) {
    serverData = {};
  }

  serverData.prefix = newPrefix;
  db.set(serverId, serverData);

  res.json({ message: 'Prefixo atualizado com sucesso', prefix: newPrefix });
});

app.get('/api/server/:id/channels', async (req, res) => {
  const serverId = req.params.id;

  try {
    const response = await axios.get(`https://discord.com/api/v10/guilds/${serverId}/channels`, {
      headers: {
        Authorization: `Bot ${token}`
      }
    });
    res.json(response.data);
  } catch (error) {
    console.error('Erro ao obter canais do servidor:', error);
    res.status(500).json({ error: 'Erro ao obter canais do servidor' });
  }
});

app.post('/api/server/:id/enable-channel', (req, res) => {
  const serverId = req.params.id;
  const { channelId } = req.body;

  if (!channelId) {
    return res.status(400).json({ error: 'channelId é obrigatório' });
  }

  const serverData = db.get(serverId) || { disabledChannels: [] };
  const index = serverData.disabledChannels.findIndex(channel => channel.channelId === channelId);

  if (index > -1) {
    serverData.disabledChannels.splice(index, 1);
    db.set(serverId, serverData);
    res.json({ message: 'Canal ativado com sucesso' });
  } else {
    res.status(400).json({ error: 'Canal não está desativado' });
  }
});

app.post('/api/server/:id/disabled-channels', (req, res) => {
  const serverId = req.params.id;
  const { channelId, channelName } = req.body;

  if (!channelId || !channelName || channelId.trim() === '' || channelName.trim() === '') {
    return res.status(400).json({ error: 'channelId e channelName são obrigatórios' });
  }

  const serverData = db.get(serverId) || {};

  if (!serverData.disabledChannels || !Array.isArray(serverData.disabledChannels)) {
    serverData.disabledChannels = [];
  }

  const channelExists = serverData.disabledChannels.find(channel => channel.channelId === channelId);
  
  if (!channelExists) {
    serverData.disabledChannels.push({ channelId, channelName });
    db.set(serverId, serverData);
    res.json({ message: 'Canal desativado com sucesso' });
  } else {
    res.status(400).json({ error: 'Canal já está desativado' });
  }
});

app.get('/api/server/:id/disabled-channels', (req, res) => {
  const serverId = req.params.id;
  const serverData = db.get(serverId);

  if (serverData && serverData.disabledChannels) {
    res.json(serverData.disabledChannels);
  } else {
    res.status(404).json({ error: 'Servidor não encontrado ou nenhum canal desativado' });
  }
});

const PORT = process.env.PORT || process.argv[2] || 3000;
app.listen(PORT, () => {
  console.log(`Servidor ouvindo na porta ${PORT}`);
});

client.login(token);