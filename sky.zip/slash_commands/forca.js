const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageActionRow, MessageButton, MessageEmbed } = require('discord.js');

const words = [
    "abacaxi", "banana", "carro", "dado", "elefante", "fogo", "gato", "hora", "igreja", "janela",
    "kiwi", "limão", "macaco", "navio", "olho", "pato", "queijo", "rato", "sapato", "tigre",
    "uva", "vaca", "xícara", "zorro", "abelha", "borboleta", "cachorro", "dinheiro", "escada", "faca",
    "girafa", "hamster", "ilha", "jacaré", "ketchup", "lápis", "morango", "navalha", "orelha", "pé",
    "quadro", "rosa", "sapo", "tesoura", "urso", "vassoura", "xadrez", "yoga", "zíper", "aniversário",
    "bola", "cama", "dedo", "eleição", "foguete", "guitarra", "hamburguer", "índio", "jardim", "lua",
    "macarrão", "naval", "oliveira", "pincel", "queimada", "raio", "salada", "touro", "sapateado", "tênis",
    "uísque", "vagão", "xarope", "yogurte", "zanzeiro", "abóbora", "borracha", "cachoeira", "diamante", "escola",
    "falcão", "hélice", "ícone", "joelho", "labirinto", "martelo", "nariz", "pipoca", "quadra", "rede",
    "sol", "tubarão", "sanduíche", "tesouro", "violão", "zebra", "amendoim", "bicicleta", "cachimbo", "dragão",
    "espada", "fita", "gorro", "helicóptero", "iogurte", "jardineiro", "limusine", "macieira", "nuvem", "ouro",
    "palhaço", "rosquinha", "tartaruga", "urubu", "ventilador", "zangão", "amor", "beleza", "doce", "floresta",
    "girassol", "honestidade", "ilusão", "mar", "natureza", "olhar", "pássaro", "quente", "relâmpago", "saudade",
    "tempo", "unicórnio", "vento", "zoológico", "agulha", "barraca", "camiseta", "dedal", "escova", "fogão",
    "gaveta", "karaokê", "nadar", "ovelha", "raquete", "vampiro", "yakult", "árvore", "cadeira", "quadrado",
    "raposa", "tubarão", "anjo", "bala", "foca", "iguana", "raposa", "urso", "biscoito", "árvore",
    "vestido", "limão", "cachorro", "faca", "lago", "onça", "verde", "amarelo", "correr", "telefone",
    "brincar", "gato", "cavalo", "baleia", "bola", "leão", "viagem", "computador", "óculos", "casa",
    "avião", "sol", "chuva", "café", "leite", "pipoca", "teatro", "música", "filme", "lua",
    "nuvem", "chave", "porta", "relógio", "rosa", "jardim", "pizza", "macarrão", "sorvete", "bolo",
    "cupcake", "abacate", "pêssego", "melancia", "laranja", "manga", "pera", "banana", "maçã", "abacaxi",
    "limão", "morango", "uva", "cereja", "pêssego", "ameixa", "kiwi", "tangerina", "framboesa", "mirtilo",
    "maracujá", "melão", "abóbora", "batata", "cenoura", "beterraba", "abobrinha", "berinjela", "alface", "repolho",
    "couve", "salsinha", "cebolinha", "coentro", "manjericão", "alecrim"]
const maxAttempts = 6;

let games = new Map(); // Store game sessions by channel ID

function getWordDisplay(word, guessedLetters) {
  return word.split('').map(letter => guessedLetters.includes(letter) ? letter : '**_**').join(' ');
}

function createGameEmbed(word, guessedLetters, attemptsLeft, gameOver) {
  const wordDisplay = getWordDisplay(word, guessedLetters);
  const embed = new MessageEmbed()
    .setColor('#0099ff')
    .setTitle('Jogo da Forca')
    .setDescription(wordDisplay)
    .addField('Tentativas Restantes', attemptsLeft.toString(), true);

  if (gameOver) {
    embed.addField('Fim de Jogo', gameOver, true);
  }

  return embed;
}

function createGameButtons() {
  const row = new MessageActionRow()
    .addComponents(
      new MessageButton()
        .setCustomId('desistir')
        .setLabel('Desistir')
        .setStyle('DANGER')
    );
  return row;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('forca')
    .setDescription('Joga um jogo da forca.'),

  async execute(interaction) {
    const channelId = interaction.channel.id;

    // Check if there is an active game in the channel
    if (games.has(channelId)) {
      await interaction.reply('Já existe um jogo em andamento neste canal. Termine-o antes de começar um novo.');
      return;
    }

    // Start a new game
    const word = words[Math.floor(Math.random() * words.length)];
    const game = {
      word,
      attempts: 0,
      guessedLetters: [],
      status: 'in_progress'
    };
    games.set(channelId, game);

    const initialMessage = await interaction.reply({
      embeds: [createGameEmbed(word, game.guessedLetters, maxAttempts, null)],
      components: [createGameButtons()],
      fetchReply: true
    });

    const filter = m => /^[a-zA-Z]+$/.test(m.content) && m.author.id === interaction.user.id;
    const collector = interaction.channel.createMessageCollector({ filter, time: 60000 });

    const buttonCollector = initialMessage.createMessageComponentCollector({ componentType: 'BUTTON', time: 60000 });

    collector.on('collect', async m => {
      const guess = m.content.toLowerCase();
      m.delete();

      if (game.status !== 'in_progress') {
        collector.stop();
        return;
      }

      if (guess.length === 1) {
        // Guess a single letter
        if (game.guessedLetters.includes(guess)) {
          await interaction.followUp({ content: 'Você já adivinhou essa letra. Tente outra.', ephemeral: true });
          return;
        }

        game.guessedLetters.push(guess);

        if (!game.word.includes(guess)) {
          game.attempts++;
        }

        let gameOver = null;
        if (game.word.split('').every(letter => game.guessedLetters.includes(letter))) {
          game.status = 'won';
          gameOver = 'Parabéns, você ganhou!';
        } else if (game.attempts >= maxAttempts) {
          game.status = 'lost';
          gameOver = `Você perdeu! A palavra era: ${game.word}`;
        }

        await interaction.editReply({
          embeds: [createGameEmbed(game.word, game.guessedLetters, maxAttempts - game.attempts, gameOver)],
          components: gameOver ? [] : [createGameButtons()]
        });

        if (gameOver) {
          games.delete(channelId);
          collector.stop();
          buttonCollector.stop();
        } else if (game.word.includes(guess)) {
          const tempMessage = await interaction.channel.send(`A letra **${guess}** está correta!`);
          setTimeout(() => tempMessage.delete(), 5000);
        } else {
          const tempMessage = await interaction.channel.send(`A letra **${guess}** está incorreta.`);
          setTimeout(() => tempMessage.delete(), 5000);
        }

      } else if (guess === game.word) {
        // Guess the entire word
        game.status = 'won';
        const gameOver = 'Parabéns, você adivinhou a palavra!';
        await interaction.editReply({
          embeds: [createGameEmbed(game.word, game.word.split(''), maxAttempts - game.attempts, gameOver)],
          components: []
        });
        games.delete(channelId);
        collector.stop();
        buttonCollector.stop();
      } else {
        game.attempts++;
        if (game.attempts >= maxAttempts) {
          game.status = 'lost';
          const gameOver = `Você perdeu! A palavra era: **${game.word}**`;
          await interaction.editReply({
            embeds: [createGameEmbed(game.word, game.guessedLetters, maxAttempts - game.attempts, gameOver)],
            components: []
          });
          games.delete(channelId);
          collector.stop();
          buttonCollector.stop();
        } else {
          await interaction.followUp({ content: 'Palavra incorreta. Tente novamente.', ephemeral: true });
        }
      }
    });

    buttonCollector.on('collect', async i => {
      if (i.customId === 'desistir') {
        const gameOver = `Você desistiu! A palavra era: ${game.word}`;
        await i.update({
          embeds: [createGameEmbed(game.word, game.guessedLetters, maxAttempts - game.attempts, gameOver)],
          components: []
        });
        games.delete(channelId);
        game.status = 'lost';
        collector.stop();
        buttonCollector.stop();
      }
    });

    collector.on('end', () => {
      if (game.status === 'in_progress') {
        interaction.editReply({
          embeds: [createGameEmbed(game.word, game.guessedLetters, maxAttempts - game.attempts, 'O jogo foi encerrado devido à inatividade.')],
          components: []
        });
        games.delete(channelId);
      }
    });
  }
};