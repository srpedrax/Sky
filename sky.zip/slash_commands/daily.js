const { SlashCommandBuilder } = require('@discordjs/builders');
const { JsonDatabase } = require('wio.db');
const db = new JsonDatabase({ databasePath: './databases/myJsonGeral.json' });
const CooldownManager = require('../utils/cooldown');
const Discord = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('daily')
    .setDescription('Resgate um mimo diário!'),
  async execute(interaction) {
    const db1 = db.get(interaction.user.id) || {};
    const cooldownTime = 24 * 60 * 60 * 1000;

    if (CooldownManager.checkCooldown("daily", interaction.user.id) > 0) {
      const remainingTime = CooldownManager.checkCooldown("daily", interaction.user.id);
      const horas = Math.floor(remainingTime / (1000 * 60 * 60));
      const minutos = Math.floor((remainingTime % (1000 * 60 * 60)) / (1000 * 60));
      const segundos = Math.floor((remainingTime % (1000 * 60)) / 1000);

      return interaction.reply({
        content: `:x:┃Você já resgatou sua recompensa diária! Aguarde ${horas} horas, ${minutos} minutos e ${segundos} segundos para resgatar seu daily novamente!`
      });
    }

    const embed = new Discord.MessageEmbed()
      .setTitle('🗓┃Recompensa Diária')
      .setDescription(`Colete sua recompensa diária [Aqui](https://sky-bot-website.web.app/bot/daily?id=${interaction.user.id})\nApós o resgate só poderá resgatar novamente em \`1 Dia\``)
      .setColor('GREEN');

    interaction.reply({ embeds: [embed] });
  },
};