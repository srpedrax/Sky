const Discord = require('discord.js');
const { SlashCommandBuilder } = require('@discordjs/builders');
const { JsonDatabase } = require('wio.db');
const db = new JsonDatabase({ databasePath: './databases/myJsonGeral.json' });
const CooldownManager = require('../utils/cooldown');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('daily')
    .setDescription('Resgate um mimo diário!'),
  async execute(interaction) {
    const db1 = db.get(interaction.user.id) || {};
    const cooldownTime = 24 * 60 * 60 * 1000; // 1 dia

    if (CooldownManager.checkCooldown("daily", interaction.user.id) > 0) {
      const remainingTime = CooldownManager.checkCooldown("daily", interaction.user.id);
      const horas = Math.floor(remainingTime / (1000 * 60 * 60));
      const minutos = Math.floor((remainingTime % (1000 * 60 * 60)) / (1000 * 60));
      const segundos = Math.floor((remainingTime % (1000 * 60)) / 1000);

      await interaction.reply({
        content: `Aguarde ${horas} horas, ${minutos} minutos e ${segundos} segundos antes de resgatar novamente.`,
        ephemeral: true,
      });
      return;
    }

    const random = Math.floor(Math.random() * 3000) + 1;

    db1.skyCoin = (db1.skyCoin ?? 0) + random;

    const embed = new Discord.MessageEmbed()
      .setTitle('🗓 | Recompensa Diária')
      .setDescription(`Parabéns <@${interaction.user.id}> você ganhou ${random} Sky Coin`)
      .setColor('GREEN');

    await interaction.reply({ embeds: [embed] });

    db.set(interaction.user.id, db1);

    CooldownManager.setCooldown("daily", interaction.user.id, cooldownTime);
  },
};

