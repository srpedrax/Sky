const { SlashCommandBuilder } = require('@discordjs/builders');
const axios = require('axios');
const { MessageActionRow, MessageButton, MessageEmbed } = require('discord.js');

let results = []; // Armazena os resultados da pesquisa

module.exports = {
  data: new SlashCommandBuilder()
    .setName('usersearch')
    .setDescription('Procura usuários de Roblox por palavra-chave.')
    .addStringOption(option =>
      option.setName('keyword')
        .setDescription('Palavra-chave de pesquisa')
        .setRequired(true)),
  async execute(interaction) {
    const keyword = interaction.options.getString('keyword');
    const limit = 100; // Limite de pesquisa
    let page = 1; // Página inicial
    let totalPages;
    try {
    	interaction.deferReply();
      const embed = await searchAndCreateEmbed(interaction, keyword, limit, page);
      const row = createPaginationRow(page);

      const message = await interaction.editReply({ embeds: [embed], components: [row], fetchReply: true });

      const filter = i => i.user.id === interaction.user.id;
      const collector = interaction.channel.createMessageComponentCollector({ filter, time: 60000 });

      collector.on('collect', async i => {
        if (i.customId === 'prev' && page > 1) {
          page--;
          i.deferUpdate();
        } else if (i.customId === 'next') {
          page++;
          i.deferUpdate();
        }
        
        

        const newEmbed = await searchAndCreateEmbed(interaction, keyword, limit, page);
        embed.setDescription(newEmbed.description);
        embed.setFields(newEmbed.fields);

        row.components[0].setDisabled(page === 1);
        row.components[1].setDisabled(page === totalPages);

        await message.edit({ embeds: [embed], components: [row] });
      });

      collector.on('end', () => {
        row.components.forEach(button => button.setDisabled(true));
        message.edit({ components: [row] });
      });
    } catch (error) {
      console.error('Erro ao buscar usuários:', error);
    }
  },
};

async function searchAndCreateEmbed(interaction, keyword, limit, page) {
  // Se a página for 1 ou os resultados estiverem vazios, faça uma nova pesquisa
  try {
  const response = await axios.get('https://users.roblox.com/v1/users/search', {
    params: {
      keyword: keyword,
      limit: limit
    }
  });

  results = response.data.data;
} catch (error) {
  if (error.response) {
    // Se houver uma resposta do servidor com um código de status HTTP fora do intervalo de 2xx
    console.error('Erro na resposta do servidor:', error.response.data);
    console.error('Status HTTP:', error.response.status);
    const errorCode = error.response.data.errors[0].code;
    
    if (errorCode === 5) {
      await interaction.editReply('A palavra-chave foi filtrada. Por favor, tente outra.');
      return;
    } else if (errorCode === 6) {
      await interaction.editReply('A palavra-chave é muito curta. Por favor, forneça uma palavra-chave mais longa.');
      return;
    } else if (errorCode === 0) {
      await interaction.editReply({ content: 'Houve muitas solicitações. Por favor, aguarde um pouco e tente novamente.', ephemeral: true });
      return;
    } else {
      await interaction.editReply('Houve um erro ao processar a solicitação. Por favor, tente novamente mais tarde.');
      return;
    }
  } else {
    // Se não houver resposta do servidor (por exemplo, timeout, falha de rede, etc.)
    console.error('Erro ao processar a solicitação:', error.message);
    await interaction.editReply('Houve um erro ao processar a solicitação. Por favor, tente novamente mais tarde.');
    return;
  }
}

  if (!results || results.length === 0) {
    return interaction.editReply({ content: "Usuários não encontrados", ephemeral: true });
  }

  totalPages = Math.ceil(results.length / 10); // Sempre exibir 10 resultados por página

  const embed = new MessageEmbed()
    .setColor('#0099ff')
    .setTitle(`Resultado da pesquisa por "${keyword}"`)
    .setDescription(`Página ${page}/${totalPages}`);

  const start = (page - 1) * 10;
  const end = Math.min(start + 10, results.length);
  for (let i = start; i < end; i++) {
    embed.addField(`Usuário ${i + 1}`, `**Nome de exibição:** ${results[i].displayName}\n**Nome de usuário:** ${results[i].name}\n**ID:** ${results[i].id}`);
  }

  return embed;
}

function createPaginationRow(page) {
  const row = new MessageActionRow()
    .addComponents(
      new MessageButton()
        .setCustomId('prev')
        .setLabel('⬅️')
        .setStyle('PRIMARY')
        .setDisabled(page === 1),
      new MessageButton()
        .setCustomId('next')
        .setLabel('➡️')
        .setStyle('PRIMARY')
        .setDisabled(page === totalPages)
    );

  return row;
}