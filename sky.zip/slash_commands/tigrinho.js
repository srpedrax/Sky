const Discord = require('discord.js');
const { SlashCommandBuilder } = require('@discordjs/builders');
const { JsonDatabase } = require('wio.db');
const db = new JsonDatabase({ databasePath: './databases/myJsonGeral.json' });

module.exports = {
  data: new SlashCommandBuilder()
    .setName('tigrinho')
    .setDescription('Jogue o jogo do tigrinho!')
    .addIntegerOption(option =>
      option.setName('aposta')
        .setDescription('A quantidade que você quer apostar')
        .setRequired(true)),
  async execute(interaction) {
    let aposta = interaction.options.getInteger('aposta');
    let db1 = db.get(interaction.user.id) || {};

    // Verificação de saldo e aposta mínima
    if (aposta < 10) {
      await interaction.reply({
        content: `A aposta mínima é de 10 Sky Coins.`,
        ephemeral: true,
      });
      return;
    } else if ((db1.skyCoin ?? 0) < aposta) {
      await interaction.reply({
        content: `Desculpe, mas você não tem Sky Coins suficientes para fazer essa aposta.`,
        ephemeral: true,
      });
      return;
    }

    const row = new Discord.MessageActionRow()
      .addComponents(
        new Discord.MessageButton()
          .setCustomId('min')
          .setLabel('Aposta Mínima')
          .setEmoji('🔻')
          .setStyle('SECONDARY'),
        new Discord.MessageButton()
          .setCustomId('decrease')
          .setLabel('Diminuir')
          .setEmoji('➖')
          .setStyle('SECONDARY'),
        new Discord.MessageButton()
          .setCustomId('result')
          .setLabel('Resultado')
          .setEmoji('🎲')
          .setStyle('PRIMARY'),
        new Discord.MessageButton()
          .setCustomId('increase')
          .setLabel('Aumentar')
          .setEmoji('➕')
          .setStyle('SECONDARY'),
        new Discord.MessageButton()
          .setCustomId('max')
          .setLabel('Aposta Máxima')
          .setEmoji('🔺')
          .setStyle('SECONDARY'),
      );

    const embed = new Discord.MessageEmbed()
      .setTitle('🐯 | Jogo do Tigrinho')
      .setDescription(`Sua aposta atual é **${aposta}** Sky Coins\nSeu saldo é **${db1.skyCoin}** Sky Coins`)
      .setColor('ORANGE')
      .setFooter('Use os botões abaixo para ajustar sua aposta');

    const message = await interaction.reply({ embeds: [embed], components: [row], fetchReply: true });

    const filter = i => i.user.id === interaction.user.id;
    const collector = message.createMessageComponentCollector({ filter, time: 600000 });

    collector.on('collect', async i => {
      if (i.customId === 'min') {
        aposta = 10;
      } else if (i.customId === 'decrease') {
        if (aposta <= 10) {
          await i.reply({ content: `A aposta mínima é de 10 Sky Coins.`, ephemeral: true });
          return;
        }
        aposta -= 10;
      } else if (i.customId === 'increase') {
        if ((db1.skyCoin ?? 0) < aposta + 10) {
          await i.reply({ content: `Desculpe, mas você não tem Sky Coins suficientes para aumentar a aposta.`, ephemeral: true });
          return;
        }
        aposta += 10;
      } else if (i.customId === 'max') {
        aposta = db1.skyCoin;
      } else if (i.customId === 'result') {
        const random = Math.random();
        let resultEmbed;

        if (random < 0.75) { // 75% de chance de perder
          db1.skyCoin -= aposta;
          resultEmbed = new Discord.MessageEmbed()
            .setTitle('🐯 | Jogo do Tigrinho')
            .setDescription(`😢 Que pena <@${i.user.id}>, você perdeu **${aposta}** Sky Coins`)
            .setColor('RED');
        } else { // 25% de chance de ganhar
          // O usuário ganha o dobro do que apostou
          const ganho = aposta * 2;
          db1.skyCoin += ganho;
          resultEmbed = new Discord.MessageEmbed()
            .setTitle('🐯 | Jogo do Tigrinho')
            .setDescription(`🎉 Parabéns <@${i.user.id}>! Você ganhou **${ganho}** Sky Coins!`)
            .setColor('GREEN');

          // Chance mínima de soltar a cartinha
          const chanceCartinha = Math.random();
          if (chanceCartinha < 0.1) { // 10% de chance
            const multiplicador = Math.floor(Math.random() * (10 - 2 + 1)) + 2; // Multiplicador aleatório entre 2 e 10
            const ganhoExtra = aposta * multiplicador;
            db1.skyCoin += ganhoExtra;
            let bonusName = '';
            if (multiplicador >= 3 && multiplicador <= 5) {
              bonusName = 'Ganho Bônus';
            } else if (multiplicador >= 6 && multiplicador <= 7) {
              bonusName = 'Grande Ganho';
            } else if (multiplicador >= 8 && multiplicador <= 9) {
              bonusName = 'Mega Ganho';
            } else if (multiplicador === 10) {
              bonusName = 'Super Ganho';
            }
            resultEmbed.addField(`${bonusName}!`, `✨ O tigrinho soltou a cartinha e você ganhou **${ganhoExtra}** Sky Coins extra!`);
          }
        }

        await i.update({ embeds: [resultEmbed], components: [] });
        db.set(interaction.user.id, db1);
        collector.stop();
        return;
      }

      const updatedEmbed = new Discord.MessageEmbed()
        .setTitle('🐯 | Jogo do Tigrinho')
        .setDescription(`Sua aposta atual é **${aposta}** Sky Coins\nSeu saldo é **${db1.skyCoin}** Sky Coins`)
        .setColor('ORANGE')
        .setFooter('Use os botões abaixo para ajustar sua aposta');

      await i.update({ embeds: [updatedEmbed] });
    });

    collector.on('end', collected => {
      message.edit({ components: [] });
    });
  },
};