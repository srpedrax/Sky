const { SlashCommandBuilder } = require('@discordjs/builders');
const { JsonDatabase } = require('wio.db');
const Discord = require('discord.js');
const dbG = new JsonDatabase({ databasePath: './databases/myJsonGeral.json' });

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Verifique as informações da Sky!'),
  async execute(interaction, client) {
    const embed = new Discord.MessageEmbed()
    .setTitle(`Minhas Informações`)
    .setDescription(`Olá <@${interaction.user.id}>, sou a Sky! Como você se chama?\n\nApesar de ainda estar em desenvolvimento, já sou muito útil, oferecendo comandos de diversão para alegrar você e os membros do seu servidor.\n\nJunte-se ao meu servidor para:\n\n- ** Explorar meus comandos **\n- ** Conhecer minhas regras **\n- ** Tirar suas dúvidas **\n- ** Ficar por dentro das novidades **`)
    .setThumbnail(client.user.displayAvatarURL())
    .setColor('BLUE');
    
    const b_one = new Discord.MessageButton()
    .setURL('https://discord.com/invite/N8fDe8nG6Z')
    .setLabel('Entre em meu servidor agora!')
    .setStyle('LINK');
    
    const row = new Discord.MessageActionRow().addComponents(b_one)
    
    interaction.reply({ content: `<@${interaction.user.id}>`, embeds: [embed], components: [row] });
  },
};