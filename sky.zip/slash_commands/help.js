const { SlashCommandBuilder } = require('@discordjs/builders');
const { JsonDatabase } = require('wio.db');
const { MessageEmbed, MessageButton, MessageActionRow } = require('discord.js');

// Inicializa a base de dados
const dbG = new JsonDatabase({ databasePath: './databases/myJsonGeral.json' });

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ajuda')
    .setDescription('Precisa de uma ajudinha?'),

  async execute(interaction, client) {
    // Cria o embed da mensagem com as informações do bot
    const embed = new MessageEmbed()
      .setTitle('Minhas Informações')
      .setDescription(`Olá <@${interaction.user.id}>, sou a Sky! Como você se chama?\n\n` +
      `Apesar de ainda estar em desenvolvimento, já sou muito útil, oferecendo comandos de diversão para alegrar você e os membros do seu servidor.\n\n` +
      `Acesse meus comandos em:\nhttps://sky-bot-website.web.app/bot/commands\n` +
      `Acesse minha dashboard em:\nhttps://sky-bot-website.web.app/home/dashboard\n` +
      `Um segredo? Fui feita totalmente no celular!`)
      .setThumbnail(client.user.displayAvatarURL())
      .setColor('BLUE');

    // Cria o botão com o link para o servidor do Discord
    const button = new MessageButton()
      .setURL('https://discord.com/invite/N8fDe8nG6Z')
      .setLabel('Entre em meu servidor agora!')
      .setStyle('LINK');

    // Adiciona o botão em uma linha de ação
    const row = new MessageActionRow().addComponents(button);

    // Envia a resposta da interação com o embed e o botão
    await interaction.reply({ content: `<@${interaction.user.id}>`, embeds: [embed], components: [row] });
  },
};