const { SlashCommandBuilder } = require('@discordjs/builders');
const { JsonDatabase } = require('wio.db');
const Discord = require('discord.js');
const dbG = new JsonDatabase({ databasePath: './databases/myJsonGeral.json' });
const CooldownManager = require('../utils/cooldown');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('atm')
    .setDescription('Verifique quantos Sky Coins você ou outro usuário possui!')
    .addUserOption(option => 
      option
        .setName('user')
        .setDescription('Usuário que você deseja ver')
        .setRequired(false)
    ),
  async execute(interaction) {
    const user = interaction.options.getUser('user') ?? interaction.user;
    const userData = dbG.get(user.id) || {};
    
    if (!userData || !userData.skyCoin) {
      return interaction.reply({ content: `<@${user.id}> não tem Sky Coins`, ephemeral: true });
    }

    // Deferir a resposta inicial
    await interaction.deferReply();
    
    // Filtrar apenas os usuários que têm a chave skyCoin
    const allUsers = dbG.all();
const sortedUsers = allUsers.sort((a, b) => b.data.skyCoin - a.data.skyCoin);

const userPosition = sortedUsers.findIndex(userData => userData.ID === user.id) + 1;

// Agora userPosition contém a posição do usuário no ranking
    
    // Responder com a quantidade de Sky Coins do usuário
    if (user.id === interaction.user.id) {
      if (userData.skyCoin <= 0) {
        await interaction.editReply(`Você atualmente não possui nenhum Sky Coin!`);
      } else {
        await interaction.editReply(`Você tem **${userData.skyCoin} Sky Coins**! Você está em **#${userPosition} lugar no ranking!**`);
        
        // Verificar se há uma recompensa diária disponível
        if (CooldownManager.checkCooldown("daily", interaction.user.id) <= 0) {
          await interaction.followUp({ content: `Hey! Parece que você ainda não coletou sua Recompensa Diária. Use </daily:1087702470806999041> para resgatá-la!`, ephemeral: true });
        }
      }
    } else {
      if (userData.skyCoin <= 0) {
        await interaction.editReply(`<@${user.id}> atualmente não possui nenhum Sky Coin!`);
      } else {
        await interaction.editReply(`<@${user.id}> tem **${userData.skyCoin} Sky Coins**! Ele está em **#${userPosition} lugar no ranking!**`);
      }
    }
  },
};