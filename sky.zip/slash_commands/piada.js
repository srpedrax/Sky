const { SlashCommandBuilder } = require('@discordjs/builders');

// Array de piadas personalizadas
const piadas = [
  "O marido chega para a esposa e pergunta: - Amor, quando eu morrer você vai chorar muito no meu velório? Então, ela responde: - Claro, amor. Você sabe que eu choro por qualquer bobeira.",
  "O que o pato disse para a pata? - Vem quá.",
  "A plantinha foi à emergência do hospital, mas não conseguiu ser atendida, por quê? Porque lá só tinha médico de plantão.",
  "Qual foi a primeira vez que os americanos comeram carne? Quando chegou Cristóvão Com Lombo.",
  "Porque o bombeiro não gosta de andar? Porque ele so-corre.",
  "Na sala de aula, a professora disse: - Quem se acha burro, fique em pé. Dudu se levanta. A professora diz: - Você se acha burro, Dudu? Não, professora. Mas fiquei com pena de ver a senhora em pé, sozinha.",
  "Porque não falta energia elétrica nos quartéis? Porque todos os cabos já foram soldados.",
  "Qual é a tecla preferida do astronauta? O espaço.",
  "O que é uma mulher velha sem relógio? Uma Sem Hora.",
  "O que a banana suicida falou? - 'Macacos me mordam!'",
  "Você conhece a piada do pônei? - Pô neim eu.",
  "Qual posição você mais gosta e sente mais prazer? - Em pé, tirando dinheiro do caixa eletrônico.",
  "A mulher chega para o atendente da farmácia e pergunta: - Você tem algo contra a tosse? - Não, pode tossir à vontade.",
  "Minha mãe disse que iria jogar meu celular pela janela. Respondi: - Pode jogar, está no modo avião.",
  "O marido diz para a mulher: - Se prepara que essa noite vai ser quente! - Sério, amor? - Sim, eu acabei de quebrar o ventilador.",
  "Beba suco devagar. Para que ele seja suculento.",
  "Sabe porque o policial não gosta de sabão em pó? Porque ele gosta de deter-gente.",
  "Quando eu tiver um casal de filhos gêmeos, o nome de um será Som e o outro se chamará Dj. Quando um estiver brigando com outro, eu posso gritar: - 'Solta o Som, Dj!'",
  "E eu sou a fu. - Que fu? - Fumiga. - E eu sou a ota. - Que ota? - Otafumiga.",
  "O que é um piolho na cabeça de um careca? Um sem terra.",
  "Num velório, um menino pergunta: - Senhora, qual a senha do wifi? - Respeita o falecido! - Mas é tudo junto?",
  "Qual remédio avisa que você está bêbado? Paracetamal.",
  "Porque a Maria só tem chulé no pé esquerdo? Porque quando pequena, a mãe dela falava: 'Lava esse pé direito, Maria!'",
  "Qual a diferença entre a pizza e a sua opinião? - É que a pizza eu pedi.",
  "O que a vaga disse para o boi? Te amuuuuuu",
  "O filho discutia com o pai, insistindo e teimando que 1+1 são 11. O pai disse: - Vá até a sorveteria e compre dois picolés. O filho voltou com os dois picolés e o pai disse: - Agora me dê 1 e dê o outro para o seu irmão. Chateado, o filho perguntou: - E o meu? O pai responde: - Fique com os 9 que sobraram.",
  "Se nada der certo, vou vender amendoim na porta da igreja. Daí, quando o padre gritar 'amém' eu digo 'doim!'",
  "Todas as frutas foram tirar férias nas montanhas, menos o mamão. Sabe porquê? Porque o mamão foi papaia.",
  "Um vizinho pergunta o outro: - Que festa foi aquela que teve aqui ontem? - Foi um casamento. - Sério? Que legal. Como estão os noivos? - O noivo está no cemitério, e a noiva no hospital. - Nossa, o que houve? - Nada, ué. O noivo é coveiro e a noiva é enfermeira.",
  "Um passarinho vinha em alta velocidade na estrada, quando de repente bateu muito forte de frente com um motoqueiro. O passarinho desmaiou e com pena, o motoqueiro o levou para casa para cuidar dele. Quando acordou, o passarinho se viu dentro de uma gaiola e falou: - 'Eita, lasqueira. Tô preso! Matei o motoqueiro!'",
  "Na sala de aula, a professora falou: - Nando, me diga uma frase com a palavra capacidade. - Claro: os zoio, os zouvido, e as zorelhas.",
  "Um homem perguntou se eu era bom em matemática. Respondi que sim. Então ele disse: - Quanto é 51 dividido por 2? - Meio litro para cada.",
  "Eu sou tão sedentário que se você me ver correr, corre também porque algo deu errado.",
  "- Moço, tem shampoo? - Para qual tipo de cabelo? - Sujo mesmo...",
  "A professora pergunta: - Quem quer ir para o céu? Todos levantam a mão, menos o Dudu. A professora diz: - E você, Dudu? Não quer ir para o céu? - Querer eu quero, mas minha disse que depois da aula era para ir direto para casa.",
  "Joãozinho parou a sua bicicleta em frente a Câmara dos Deputados. Um segurança da Câmara chega e diz: - Joãozinho, tire essa bicicleta daqui, os deputados estão chegando. - Não se preocupe, eu coloquei cadeado.",
  "O que uma gota falou para a outra? Gotosa.",
  "A mulher diz para o marido: - Se eu soubesse que você era tão pobre, não teria me casado contigo. O marido responde: - Eu sempre disse que você é a única coisa que eu tinha.",
  "O que um sapo faz dentro do computador? Foi procurar a memória-ram.",
  "O que o exaltassamba foi fazer na biblioteca? - lêlêlêlêlê lêlêlêlê.",
  "O que a zebra falou para o carrapato? - Você está na minha listra negra.",
  "Professora diz: - Pedrinho, cite três partes do corpo humano que comecem com a letra z. - Claro: os zoio, os zouvido, e as zorelhas. - Que resposta horrível, Pedrinho. Só por isso vai receber uma nota que também começa com a letra z. - hmmm, uns zoito?",
  "Porque o amor entre os patos é o amor mais bonito? Porque é um amor patodavida.",
  "Porque os minions não usam GPS? Porque já sabem os caminions.",
  "Qual é o pote que toca música? O sPOTEfy.",
  "Qual é o tipo de conexão que não funciona no elevador? A interet dISCADA",
  "Qual macarrão parou de ficar com os outros? Ex-peguete (espaguete)"
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('piada')
    .setDescription('Obtenha uma piada engraçada.'),

  execute(interaction) {
    // Escolhe uma piada aleatória do array
    const piada = piadas[Math.floor(Math.random() * piadas.length)];
    
    // Responde com a piada
    interaction.reply(`${piada}`);
  },
};