const Discord = require('discord.js');
const { SlashCommandBuilder } = require('@discordjs/builders');
const { JsonDatabase } = require('wio.db');
const db = new JsonDatabase({ databasePath: './databases/myJsonGeral.json' });

const cooldowns = new Map();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('transferir')
    .setDescription('Transfira uma quantidade de Sky Coins!')
    .addUserOption(option =>
      option.setName('recebedor')
        .setDescription('Pessoa que você irá transferir a Sky Coins')
        .setRequired(true))
    .addNumberOption(option =>
      option.setName('quantidade')
        .setDescription('Quantidade de Sky Coins que irá transferir')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('tempo')
        .setDescription('Tempo que o recebedor tem para aceitar a transferência (ex: 1m, 2h)')
        .setRequired(false)),
  async execute(interaction) {
    const payer = interaction.user;
    const receiver = interaction.options.getUser('recebedor');
    const amount = interaction.options.getNumber('quantidade');
    const timeOption = interaction.options.getString('tempo');
    const timeLimit = convertTimeStringToMs(timeOption) || 300000; // Default to 5 minutes if not specified

    // Verificar se o receptor não é um bot
    if (receiver.bot) {
      await interaction.reply({ content: 'Você não pode transferir Sky Coins para um bot.', ephemeral: true });
      return;
    }

    // Verificar se o usuário não está tentando transferir para si mesmo
    if (payer.id === receiver.id) {
      await interaction.reply({ content: 'Você não pode transferir Sky Coins para si mesmo.', ephemeral: true });
      return;
    }

    // Obter o saldo do pagador
    let payerBalance = db.get(payer.id) || { skyCoin: 0 };

    // Verificar se o pagador tem saldo suficiente
    if (payerBalance.skyCoin < amount) {
      await interaction.reply({ content: 'Você não tem saldo suficiente para realizar esta transferência.', ephemeral: true });
      return;
    }

    // Obter o saldo do receptor ou definir como 0 se ainda não existir
    let receiverBalance = db.get(receiver.id) || { skyCoin: 0 };

    // Criar os botões para aceitar ou rejeitar a transferência
    const row = new Discord.MessageActionRow()
      .addComponents(
        new Discord.MessageButton()
          .setCustomId('aceitar_transferencia')
          .setLabel('Aceitar')
          .setStyle('SUCCESS'),
        new Discord.MessageButton()
          .setCustomId('rejeitar_transferencia')
          .setLabel('Rejeitar')
          .setStyle('DANGER')
      );

    const timestamp = new Date(Date.now() + timeLimit);
    const timeString = `<t:${Math.floor(timestamp.getTime() / 1000)}:F> (<t:${Math.floor((Date.now() + timeLimit) / 1000)}:R>)`;

    // Enviar embed solicitando aceitação da transferência
    const embed = new Discord.MessageEmbed()
      .setTitle('Solicitação de Transferência de Sky Coins')
      .setDescription(`Transferência de **${amount}** Sky Coins para <@${receiver.id}>.\n<@${receiver.id}>, você tem até ${timeString} para aceitar ou rejeitar a transferência.`)
      .setColor('BLUE');

    await interaction.reply({ embeds: [embed], components: [row] });

    const filter = i => [payer.id, receiver.id].includes(i.user.id);
    const collector = interaction.channel.createMessageComponentCollector({ filter, time: timeLimit });

    collector.on('collect', async i => {
      if (i.customId === 'aceitar_transferencia') {
        if (i.user.id !== receiver.id) {
          await i.reply({ content: 'Apenas o recebedor pode aceitar a transferência.', ephemeral: true });
          return;
        }

        // Subtrair o saldo do pagador
        payerBalance.skyCoin -= amount;

        // Adicionar o saldo ao receptor
        receiverBalance.skyCoin += amount;

        // Atualizar os saldos no banco de dados
        db.set(payer.id, payerBalance);
        db.set(receiver.id, receiverBalance);

        // Enviar embed confirmando a transferência e mostrando os saldos
        const confirmEmbed = new Discord.MessageEmbed()
          .setTitle('Transferência de Sky Coins')
          .setDescription(`Transferência de **${amount}** Sky Coins para <@${receiver.id}> realizada com sucesso.\n\n**Saldo Atual:**\n<@${payer.id}>: ${payerBalance.skyCoin} Sky Coins\n<@${receiver.id}>: ${receiverBalance.skyCoin} Sky Coins`)
          .setColor('GREEN');

        await i.update({ embeds: [confirmEmbed], components: [] });
        collector.stop();
      } else if (i.customId === 'rejeitar_transferencia') {
        if (![payer.id, receiver.id].includes(i.user.id)) {
          await i.reply({ content: 'Apenas o pagador ou o recebedor pode cancelar a transferência.', ephemeral: true });
          return;
        }

        await i.update({ content: 'Transferência rejeitada.', components: [] });
        collector.stop();
      }
    });

    collector.on('end', collected => {
      if (collected.size === 0) {
        interaction.followUp({ content: 'A solicitação de transferência expirou.', ephemeral: true });
      }
    });
  },
};

function convertTimeStringToMs(timeString) {
  if (!timeString) return null;
  const regex = /^(\d+)([smhd])$/;
  const match = regex.exec(timeString);
  if (!match) return null;

  const value = parseInt(match[1], 10);
  const unit = match[2];

  switch (unit) {
    case 's': return value * 1000; // seconds to ms
    case 'm': return value * 60000; // minutes to ms
    case 'h': return value * 3600000; // hours to ms
    case 'd': return value * 86400000; // days to ms
    default: return null;
  }
}