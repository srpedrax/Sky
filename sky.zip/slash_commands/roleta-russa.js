const Discord = require('discord.js');
const { SlashCommandBuilder } = require('@discordjs/builders');
const { JsonDatabase } = require('wio.db');
const db = new JsonDatabase({ databasePath: './databases/myJsonGeral.json' });

module.exports = {
  data: new SlashCommandBuilder()
    .setName('roletarussa')
    .setDescription('Jogue uma rodada de Roleta Russa!')
    .addIntegerOption(option =>
      option.setName('aposta')
        .setDescription('A quantidade que você quer apostar')
        .setRequired(true)),
  async execute(interaction) {
    let aposta = interaction.options.getInteger('aposta');
    const db1 = db.get(interaction.user.id) || {};

    if (aposta < 10) {
      await interaction.reply({
        content: `A aposta mínima é de 10 Sky Coins.`,
        ephemeral: true,
      });
      return;
    } else if ((db1.skyCoin ?? 0) < aposta) {
      await interaction.reply({
        content: `Desculpe, mas você não tem Sky Coins suficientes para fazer essa aposta.`,
        ephemeral: true,
      });
      return;
    }

    let rodada = 1;
    let ganhos = aposta;
    let message;

    const multiplicadores = [2, 4, 6, 7, 9, 10];

    const jogarRoleta = async (interaction, collector) => {
      const random = Math.random();
      let resultEmbed;

      if (random < 1 / (7 - rodada + 1)) { // Probabilidade de perder aumenta a cada rodada
        db1.skyCoin -= aposta;
        resultEmbed = new Discord.MessageEmbed()
          .setTitle('🔫 | Roleta Russa')
          .setDescription(`💥 **Bang!** Que pena <@${interaction.user.id}>, você perdeu **${ganhos}** Sky Coins`)
          .setColor('RED');
        await interaction.update({ embeds: [resultEmbed], components: [] });
        db.set(interaction.user.id, db1);
        collector.stop();
      } else { // Chance de ganhar
        ganhos = ganhos * multiplicadores[rodada - 1];
        rodada++;
        if (rodada > 7) {
          db1.skyCoin += ganhos;
          resultEmbed = new Discord.MessageEmbed()
            .setTitle('🔫 | Roleta Russa')
            .setDescription(`😅 **Click!** Parabéns <@${interaction.user.id}>, você sobreviveu todas as rodadas e ganhou **${ganhos}** Sky Coins!`)
            .setColor('GREEN');
          await interaction.update({ embeds: [resultEmbed], components: [] });
          db.set(interaction.user.id, db1);
          collector.stop();
        } else {
          resultEmbed = new Discord.MessageEmbed()
            .setTitle('🔫 | Roleta Russa')
            .setDescription(`😅 **Click!** Parabéns <@${interaction.user.id}>, você sobreviveu esta rodada e agora tem **${ganhos}** Sky Coins!\n\nVocê quer tentar novamente? (Rodada ${rodada} de 7 com multiplicador x${multiplicadores[rodada - 1]})`)
            .setColor('GREEN');
          const row = new Discord.MessageActionRow()
            .addComponents(
              new Discord.MessageButton()
                .setCustomId('continuar')
                .setLabel('Continuar')
                .setEmoji('🔫')
                .setStyle('PRIMARY'),
              new Discord.MessageButton()
                .setCustomId('parar')
                .setLabel('Parar')
                .setStyle('SECONDARY')
            );
          await interaction.update({ embeds: [resultEmbed], components: [row] });
        }
      }
    };

    const row = new Discord.MessageActionRow()
      .addComponents(
        new Discord.MessageButton()
          .setCustomId('puxar_gatilho')
          .setLabel('Puxar o Gatilho')
          .setEmoji('🔫')
          .setStyle('PRIMARY')
      );

    const embed = new Discord.MessageEmbed()
      .setTitle('🔫 | Roleta Russa')
      .setDescription(`Você apostou **${aposta}** Sky Coins\nClique no botão abaixo para puxar o gatilho.`)
      .setColor('#8b0000')
      .setFooter('Boa sorte!');

    message = await interaction.reply({ embeds: [embed], components: [row], fetchReply: true });

    const filter = i => i.user.id === interaction.user.id;
    const collector = message.createMessageComponentCollector({ filter, time: 600000 });

    collector.on('collect', async i => {
      if (i.customId === 'puxar_gatilho' || i.customId === 'continuar') {
        await jogarRoleta(i, collector);
      } else if (i.customId === 'parar') {
        db1.skyCoin += ganhos;
        const resultEmbed = new Discord.MessageEmbed()
          .setTitle('🔫 | Roleta Russa')
          .setDescription(`Parabéns <@${i.user.id}>, você decidiu parar e levou para casa **${ganhos}** Sky Coins!`)
          .setColor('GREEN');
        await i.update({ embeds: [resultEmbed], components: [] });
        db.set(interaction.user.id, db1);
        collector.stop();
      }
    });

    collector.on('end', collected => {
      if (collected.size === 0) {
        message.edit({ content: 'Tempo esgotado! Você não puxou o gatilho a tempo.', components: [] });
      }
    });
  },
};