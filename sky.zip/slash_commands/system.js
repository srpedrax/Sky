const { SlashCommandBuilder } = require('@discordjs/builders');
const { JsonDatabase } = require('wio.db');
const Discord = require('discord.js');
const dbG = new JsonDatabase({ databasePath: './databases/myJsonGeral.json' });

module.exports = {
  data: new SlashCommandBuilder()
    .setName('system')
    .setDescription('Faça alterações em meu sistema.')
    .addSubcommand(subcommand =>
      subcommand
        .setName('ban')
        .setDescription('Banir um usuário de meu sistema!')
        .addUserOption(option =>
          option.setName('user')
            .setDescription('O usuário a banir.')
            .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('unban')
        .setDescription('Desbanir um usuário do meu sistema!')
        .addUserOption(option =>
          option.setName('user')
            .setDescription('O usuário a desbanir.')
            .setRequired(true))),
  async execute(interaction) {
    if (interaction.user.id !== '681831921239851069') {
      return interaction.reply({ content: '❌️ | Apenas meu dono pode usar esse comando!', ephemeral: true });
    }
    const subcommand = interaction.options.getSubcommand();
    const ip = interaction.options.getUser('user');

    if (subcommand === 'ban') {
      const db = dbG.get(ip.id);
      if (db && db.isBanned) {
        return interaction.reply({ content: `Usuário <@${ip.id}> já está banido!`, ephemeral: true });
      } else {
        db.isBanned = true;
        dbG.set(ip.id, db);
        return interaction.reply(`Usuário <@${ip.id}> banido do meu sistema com sucesso, ninguém mandou quebrar as regras!`);
      }
    } else if (subcommand === 'unban') {
      const db = dbG.get(ip.id);
      if (db && !db.isBanned) {
        return interaction.reply({ content: `Usuário <@${ip.id}> já está desbanido!`, ephemeral: true });
      } else {
      	db.isBanned = false;
        dbG.set(ip.id, db);
        return interaction.reply(`Usuário <@${ip.id}> desbanido do meu sistema com sucesso. Bem-vindo novamente!`);
      }
    }
  },
};