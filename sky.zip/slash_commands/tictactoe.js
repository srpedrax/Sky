const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageActionRow, MessageButton, MessageEmbed } = require('discord.js');

let board = [
  [' ', ' ', ' '],
  [' ', ' ', ' '],
  [' ', ' ', ' ']
];
const gamesByChannel = new Map();
let currentPlayer = 'X';
let challenger = null;

function checkWinner() {
  for (let i = 0; i < 3; i++) {
    if (board[i][0] !== ' ' && board[i][0] === board[i][1] && board[i][0] === board[i][2]) {
      return board[i][0];
    }
  }
  for (let j = 0; j < 3; j++) {
    if (board[0][j] !== ' ' && board[0][j] === board[1][j] && board[0][j] === board[2][j]) {
      return board[0][j];
    }
  }
  if (board[0][0] !== ' ' && board[0][0] === board[1][1] && board[0][0] === board[2][2]) {
    return board[0][0];
  }
  if (board[0][2] !== ' ' && board[0][2] === board[1][1] && board[0][2] === board[2][0]) {
    return board[0][2];
  }
  return null;
}

function displayBoard() {
  let boardString = '';
  for (let i = 0; i < 3; i++) {
    boardString += `${board[i].join(' | ')}\n`;
    if (i < 2) {
      boardString += '---------\n';
    }
  }
  return boardString;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('tictactoe')
    .setDescription('Inicia um jogo da velha!')
    .addUserOption(option => option.setName('jogador').setDescription('Escolha o jogador para desafiar').setRequired(true)),
  async execute(interaction) {
    board = [
          [' ', ' ', ' '],
          [' ', ' ', ' '],
          [' ', ' ', ' ']
        ];
    currentPlayer = 'X';
    challenger = interaction.user;
    const opponent = interaction.options.getUser('jogador');

    let gamesInChannel = gamesByChannel.get(interaction.channelId);
    if (!gamesInChannel) {
      gamesInChannel = [];
      gamesByChannel.set(interaction.channelId, gamesInChannel);
    }
    
    const newGame = {
      challengerId: challenger.id,
      opponentId: opponent.id,
      board,
      currentPlayer
    };
    gamesInChannel.push(newGame);
    
    const initialBoard = displayBoard();
    const embed = new MessageEmbed()
      .setTitle('Jogo da Velha')
      .setDescription(`É a vez do jogador ${currentPlayer}`)
      .addField('Tabuleiro', '```\n' + initialBoard + '```')
      .setColor('BLUE');

    const row1 = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setCustomId('00')
          .setLabel('‎ㅤ')
          .setStyle('SECONDARY'),
        new MessageButton()
          .setCustomId('01')
          .setLabel('ㅤ')
          .setStyle('SECONDARY'),
        new MessageButton()
          .setCustomId('02')
          .setLabel('ㅤ')
          .setStyle('SECONDARY')
      );

    const row2 = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setCustomId('10')
          .setLabel('ㅤ')
          .setStyle('SECONDARY'),
        new MessageButton()
          .setCustomId('11')
          .setLabel('ㅤ')
          .setStyle('SECONDARY'),
        new MessageButton()
          .setCustomId('12')
          .setLabel('ㅤ')
          .setStyle('SECONDARY')
      );

    const row3 = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setCustomId('20')
          .setLabel('ㅤ')
          .setStyle('SECONDARY'),
        new MessageButton()
          .setCustomId('21')
          .setLabel('ㅤ')
          .setStyle('SECONDARY'),
        new MessageButton()
          .setCustomId('22')
          .setLabel('ㅤ')
          .setStyle('SECONDARY')
      );

    await interaction.reply({ embeds: [embed], components: [row1, row2, row3] });

    const filter = i => i.user.id === challenger.id;
    const collector = interaction.channel.createMessageComponentCollector({ filter, time: 600000 });

    collector.on('collect', async interaction => {
      const [row, col] = interaction.customId.split('');
      await handlePlayerMove(currentPlayer, row, col, interaction);
    });

    collector.on('end', () => {
      interaction.followUp('Tempo esgotado. O jogo foi encerrado.');
    });
  },
};

async function handlePlayerMove(player, row, col, interaction) {
  if (player !== currentPlayer) {
    await interaction.reply(`Ainda não é a sua vez, jogador ${player}.`);
  } else {
    await processMove(row, col, interaction);
  }
}

async function processMove(row, col, interaction) {
  if (board[row][col] === ' ') {
    board[row][col] = currentPlayer;
    const winner = checkWinner();
    if (winner) {
      const winnerEmbed = new MessageEmbed()
        .setTitle('Jogo da Velha')
        .setDescription(`O jogador ${winner} venceu!`)
        .addField('Tabuleiro Final', '```\n' + displayBoard() + '```')
        .setColor('GREEN');
      await interaction.update({ embeds: [winnerEmbed], components: [] });
      return;
    }
    const isDraw = board.every(row => row.every(cell => cell !== ' '));
    if (isDraw) {
      const drawEmbed = new MessageEmbed()
        .setTitle('Jogo da Velha')
        .setDescription('O jogo empatou!')
        .addField('Tabuleiro Final', '```\n' + displayBoard() + '```')
        .setColor('YELLOW');
      await interaction.update({ embeds: [drawEmbed], components: [] });
      return;
    }
    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    const updatedBoard = displayBoard();
    const updatedEmbed = new MessageEmbed()
      .setTitle('Jogo da Velha')
      .setDescription(`É a vez do jogador ${currentPlayer}`)
      .addField('Tabuleiro', '```\n' + updatedBoard + '```')
      .setColor('BLUE');
    await interaction.update({ embeds: [updatedEmbed], components: interaction.message.components });
  } else {
    const tempMessage = await interaction.reply('Essa célula já está ocupada. Escolha outra.')
    setTimeout(() => tempMessage.delete(), 5000);
  }
}