const { SlashCommandBuilder } = require('@discordjs/builders');
const Discord = require('discord.js');
const https = require('https');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('minecraft')
    .setDescription('Exibe informações sobre Minecraft.')
    .addSubcommand(subcommand =>
      subcommand
        .setName('server')
        .setDescription('Exibe informações sobre um servidor Minecraft.')
        .addStringOption(option =>
          option.setName('ip')
            .setDescription('O IP do servidor.')
            .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('player')
        .setDescription('[BETA] Exibe informações sobre um jogador Minecraft.')
        .addStringOption(option =>
          option.setName('username')
            .setDescription('O nome de usuário do jogador.')
            .setRequired(true))),
  async execute(interaction) {
    const unixTimestamp = Math.floor(Date.now() / 1000);
    const embed = new Discord.MessageEmbed()
    .setTitle('Informações do servidor');
    if (interaction.options.getSubcommand() === 'server') {
      const ip = interaction.options.getString('ip');
      const serverInfo = await getServerInfo(ip);
      embed.setDescription(serverInfo);
      await interaction.reply({ embeds: [embed], ephemeral: false });
    } else if (interaction.options.getSubcommand() === 'player') {
      const username = interaction.options.getString('username');
      const playerInfo = await getPlayerInfo(username);
      await interaction.reply({ content: playerInfo, ephemeral: true });
    }
  },
};

let emoji;
let infoServerVersion;

async function getServerInfo(ip) {
  return new Promise((resolve, reject) => {
    https.get(`https://api.mcsrvstat.us/2/${ip}`, (res) => {
      let data = '';
      res.on('data', (chunk) => {
        data += chunk;
      });
      res.on('end', () => {
        const serverInfo = JSON.parse(data);
        if (!serverInfo) {
          resolve('Este servidor não existe!');
        }
        emoji = serverInfo.online ? '🟢' : '🔴'
        infoServerVersion = serverInfo.version ? serverInfo.version : "Versão não especificada";
          if (serverInfo.online) {
            resolve(`**IP:** ${serverInfo.ip}\n**Porta:** ${serverInfo.port}\n**Link:** ${serverInfo.hostname}\n**Online:** ${emoji}\n**Jogadores Online:** ${serverInfo.players.online}\n**Versão:** ${infoServerVersion}`)
            icon = serverInfo.icon;
          } else {
            resolve(`**IP:** ${serverInfo.ip}\n**Link:** ${serverInfo.hostname}\n**Online:** ${emoji}\n**Versão:** ${infoServerVersion}`)
          }
      });
    }).on('error', (err) => {
      console.error('Erro ao obter informações do servidor:', err);
      resolve('Ocorreu um erro ao obter informações do servidor. Tente novamente mais tarde! ');
    });
  });
}

async function getPlayerInfo(username) {
  return new Promise((resolve, reject) => {
  	const unixTimestamp = Math.floor(Date.now() / 1000);
    https.get(`https://api.mojang.com/users/profiles/minecraft/${username}?at=${unixTimestamp}`, (res) => {
      let data = '';
      res.on('data', (chunk) => {
        data += chunk;
      });
      res.on('end', () => {
        const playerInfo = JSON.parse(data);
        if (!playerInfo) {
          resolve('O jogador especificado não foi encontrado.');
        } else {
          resolve(`**Nome de Usuário:** ${playerInfo.name}\n**UUID:** ${playerInfo.id}`);
        }
      });
    }).on('error', (err) => {
      console.error('Erro ao obter informações do jogador:', err);
      resolve('Ocorreu um erro ao obter informações do jogador.');
    });
  });
}