const { SlashCommandBuilder } = require('@discordjs/builders');

const pickupLines = {
  'romantico': [
    'Você é uma nave espacial? Porque quando te vejo, sinto que estou em outro mundo.',
    'Se beleza desse cadeia, você pegaria prisão perpétua.',
    'Seu pai é um terrorista? Porque você é uma bomba.',
    'Posso tirar uma foto sua para provar aos meus amigos que anjos existem?',
    'Você acredita em amor à primeira vista, ou devo passar por aqui de novo?',
    'Se você fosse um livro, eu leria você em voz alta até o amanhecer.',
    'Se você fosse um mapa, eu me perderia em você o tempo todo.',
    'Você é o sol dos meus dias, a lua dos meus sonhos e a batida do meu coração.',
    'Você é como uma estrela cadente: rara, magnífica e desejada por todos.',
    'Seu sorriso ilumina o meu dia mais do que o sol.',
    'Você acredita em destino? Porque acabei de encontrar o meu ao te encontrar.',
    'Você é o que faltava na minha vida. Posso te chamar de meu?',
    'Eu não sou fotógrafo, mas posso facilmente imaginar nós dois juntos.',
    'Você é como uma poesia: bela, inspiradora e impossível de esquecer.',
    'Se eu pudesse rearranjar o alfabeto, eu colocaria o "U" e o "I" juntos.',
    'Seu sorriso é como um imã, sempre me puxando para mais perto de você.',
    'Eu não sou um cartão de crédito, mas sinto que estou totalmente em débito com você.',
    'Se o amor fosse uma flor, você seria a mais bela do jardim.',
    'Eu não sabia o que era verdadeiro amor até te conhecer.',
    'Você é tão doce que poderia causar diabetes.',
    'Não sei como você se chama, mas sei que quero que seja para sempre.',
    'Seu amor é como um raio de sol em um dia chuvoso: ilumina e aquece minha alma.',
    'Eu posso não ser um super-herói, mas estou aqui para te salvar de dias chatos.',
    'Você é o sonho que eu nunca soube que queria.',
    'Eu não sou um gênio, mas sei que você é a resposta para todas as minhas preces.',
  ],
  'engracado': [
    'Se você fosse um sanduíche, você seria um sanduíche incrível.',
    'Se você fosse um pirulito, seria sabor gostoso.',
    'Você é feito de cobre e telúrio? Porque você é Cu-Te.',
    'Você é o Google? Porque você tem tudo que eu procuro.',
    'Se eu fosse um cachorro, você me daria um biscoito?',
    'Você é um furacão? Porque você acabou de virar minha vida de cabeça para baixo.',
    'Se beleza desse dinheiro, você seria uma fortuna.',
    'Se você fosse uma fruta, você seria um abacaxi. Porque você é tão perfeito que é quase exótico.',
    'Você é como o dentista: me dá arrepio, mas ainda assim eu gosto de você.',
    'Você é tão doce que poderia ser uma confeitaria.',
    'Se você fosse uma batata, você seria uma batata de luxo.',
    'Se você fosse um sapato, você seria um chinelo porque está sempre relax.',
    'Você é como um parque de diversões: divertida, emocionante e sempre com filas.',
    'Se você fosse um Pokémon, eu escolheria você todos os dias.',
    'Você é a bateria do meu celular: sempre me deixa carregado.',
    'Você é como um filme de comédia: me faz rir e nunca me canso de te ver.',
    'Se você fosse um meme, você seria o mais engraçado da internet.',
    'Se beleza fosse comida, você seria um banquete.',
    'Você é como um emoji: sempre me faz sorrir quando te vejo.',
    'Se eu fosse um avião, você seria meu aeroporto favorito.',
    'Você é tão engraçada que poderia fazer até uma pedra rir.',
    'Você é como um show de comédia: me faz rir até doer a barriga.',
    'Se você fosse um trocadilho, você seria o melhor que já ouvi.',
    'Você é como um emoji de coração: sempre aquece meu dia.',
    'Se você fosse uma piada, seria a melhor que já ouvi.',
  ],
  'elogios': [
    'Se beleza desse crime, você já teria sido condenada à prisão perpétua.',
    'Você é como uma obra de arte: bela, única e admirável.',
    'Você é tão inteligente que poderia resolver qualquer problema do mundo.',
    'Você é o tipo de pessoa que ilumina qualquer ambiente em que entra.',
    'Seu sorriso é tão cativante que poderia parar o trânsito.',
    'Você é a definição de elegância e classe.',
    'Se você fosse uma música, seria a mais bonita já escrita.',
    'Você é como uma estrela: brilha tanto que ilumina todo o universo.',
    'Seu coração é tão generoso que poderia alimentar o mundo.',
    'Você é como um diamante: valiosa, deslumbrante e rara.',
    'Seu sorriso é como o sol: ilumina e aquece o dia de qualquer um.',
    'Você é como uma pérola: rara, preciosa e sempre desejada.',
    'Você é tão incrível que poderia ser um super-herói.',
    'Se você fosse uma paisagem, seria a mais bela já vista.',
    'Você é como um arco-íris: cheia de cores e trazendo alegria para todos.',
    'Você é a personificação da beleza e da bondade.',
    'Se você fosse uma flor, seria a mais bela do jardim.',
    'Você é como uma estrela-guia: sempre iluminando o caminho dos outros.',
    'Se você fosse uma obra de arte, seria uma obra-prima.',
    'Você é como uma pérola rara: única e incomparável.',
    'Se você fosse uma constelação, seria a mais brilhante no céu.',
    'Você é como um livro de contos de fadas: cheio de magia e encanto.',
    'Se você fosse uma nota musical, seria a mais doce melodia.',
    'Você é como um jardim em flor: belo, perfumado e sempre em crescimento.',
    'Se você fosse uma estação do ano, seria a primavera: traz vida e renovação a tudo ao seu redor.',
    'Você é como um diamante lapidado: radiante e com muitas facetas.',
    'Se eu pudesse escolher apenas uma pessoa para passar o resto da minha vida, seria você sem dúvida.',
    'Você é como um céu estrelado: infinitamente bonito e cheio de mistério.',
    'Se você fosse uma obra de arte, seria aquela que todos param para admirar.',
    'Você é como uma xícara de chocolate quente em um dia frio: reconfortante e deliciosa.',
    'Seus olhos são como estrelas brilhantes em um céu noturno.',
    'Você é como um oceano profundo: cheio de mistério e beleza infinita.',
    'Se você fosse uma dança, seria a mais graciosa de todas.',
    'Você é como um amanhecer: traz luz e esperança para um novo dia.',
    'Se você fosse uma escultura, seria esculpida com perfeição.',
    'Você é como um poema: suas palavras tocam profundamente o coração de quem te ouve.',
    'Se eu pudesse descrever você em uma palavra, seria "maravilhosa".',
    'Você é como um abraço caloroso: reconfortante e sempre bem-vindo.',
    'Se você fosse uma estrela do cinema, seria a protagonista de todas as minhas fantasias.',
    'Você é como um arco-íris após a tempestade: um sinal de esperança e beleza.',
    'Se você fosse uma pintura, seria a obra-prima de um gênio.',
    'Você é como um tesouro escondido: valiosa e esperando para ser descoberta.',
    'Se eu pudesse escrever uma história de amor, você seria a protagonista.',
    'Você é como um raio de sol em um dia nublado: ilumina e aquece tudo ao seu redor.',
    'Se você fosse uma estrela, eu desejaria por você todas as noites.',
    ],
    'educado': [
        'Com licença, você poderia me informar como chegar ao seu coração?',
        'Desculpe, mas eu acho que perdi meu número de telefone. Você pode me emprestar o seu?',
        'Com todo o respeito, você pode me dizer o seu nome? Eu gostaria de saber como chamar um anjo como você.',
        'Me perdoe, mas você poderia me ajudar a resolver uma questão? Eu não entendo como alguém tão incrível como você está solteiro(a).',
        'Com licença, mas eu queria te dizer que você tem um sorriso muito bonito.',
        'Desculpe a interrupção, mas eu gostaria de saber se posso ter a honra de te convidar para sair.',
        'Perdão, mas eu acredito que você tenha algo preso no seu sapato... Oh, desculpe, é apenas o brilho da sua beleza.',
        'Com todo o respeito, eu queria te dizer que você é a pessoa mais encantadora que já conheci.',
        'Desculpe incomodar, mas eu queria te dizer que você tem um estilo muito elegante.',
        'Com licença, mas eu acredito que você tenha deixado cair algo... Oh, foi só minha mandíbula ao te ver passar.',
        'Perdão pela minha ousadia, mas eu queria te dizer que você é absolutamente fascinante.',
        'Com todo o respeito, eu gostaria de te convidar para um café. Afinal, uma pessoa tão interessante merece uma boa conversa.',
        'Desculpe interromper, mas eu queria te dizer que você ilumina o ambiente com a sua presença.',
        'Com licença, mas eu preciso te contar que você tem um charme irresistível.',
        'Perdão, mas eu queria te dizer que você tem um perfume muito agradável.',
        'Com todo o respeito, eu gostaria de te dizer que a sua simpatia me cativou.',
        'Desculpe a intromissão, mas eu queria te dizer que você é uma pessoa verdadeiramente especial.',
        'Com licença, mas eu preciso te falar que o seu sorriso é contagiante.',
        'Perdão, mas eu queria te dizer que você tem uma energia muito positiva.',
        'Com todo o respeito, eu gostaria de dizer que você é uma pessoa muito inspiradora.',
        'Desculpe, mas eu não poderia deixar de mencionar que você é muito charmoso(a).',
        'Com licença, mas eu precisava te dizer que você é uma pessoa extremamente carismática.',
        'Perdão a ousadia, mas eu queria te dizer que você é absolutamente adorável.',
        'Com todo o respeito, eu gostaria de te dizer que a sua gentileza me encanta.',
        'Desculpe interromper, mas eu queria te dizer que você é uma pessoa de grande elegância.',
      ]
    };

function getRandomPickupLine(category = null) {
  let lines = Object.values(pickupLines).flat();
  if (category && pickupLines.hasOwnProperty(category)) {
    lines = pickupLines[category];
  }
  return lines[Math.floor(Math.random() * lines.length)];
}

async function execute(interaction) {
  const category = interaction.options.getString('categoria');
  const pickupLine = getRandomPickupLine(category);
  await interaction.reply(pickupLine);
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('cantada')
    .setDescription('Receba uma cantada aleatória.')
    .addStringOption(option =>
      option.setName('categoria')
        .setDescription('Selecione uma categoria para a cantada.')
        .setRequired(false)
        .addChoices(
          { name: 'Romântico', value: 'romantico' },
          { name: 'Engraçado', value: 'engracado' },
          { name: 'Elogios', value: 'elogios' },
          { name: 'Educado', value: 'educado' }
        )),
  execute: execute
};